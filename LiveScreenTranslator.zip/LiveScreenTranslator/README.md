# Live Screen Translator

Native Android app (Kotlin, Jetpack Compose) that reads text from other apps and games in real time and draws the
translation on top of the original, in the same place.

> **Status, read this first.** This project was written without access to an Android SDK, Gradle or a network, so it
> has **never been compiled, unit-tested or run on a device**. It was checked only by static review (bracket
> balance, internal imports, XML well-formedness). Expect to fix a handful of compile errors on the first build,
> and expect to tune timing constants on a real phone (see "Things to verify first"). No APK is included for that reason.

## Build

Requirements: Android Studio Ladybug (2024.2) or newer, JDK 17, Android SDK 35, internet for the first sync.

1. Open this folder in Android Studio and let Gradle sync. It downloads Gradle 8.9 from `gradle-wrapper.properties`.
   (`gradle-wrapper.jar` and the `gradlew` scripts could not be generated offline. To make them, run
   `gradle wrapper --gradle-version 8.9` once, or just build from Android Studio.)
2. Run **Build > Build APK(s)**, or from a terminal: `./gradlew assembleDebug`
   → `app/build/outputs/apk/debug/app-debug.apk`
3. Unit tests (pure JVM, no device): `./gradlew testDebugUnitTest`
4. Install: `adb install -r app/build/outputs/apk/debug/app-debug.apk`

minSdk 26, targetSdk 35. Debug build only; no signing config for release.

## Using it

1. Complete onboarding and allow **Display over other apps**.
2. Settings → **Offline language packs**: download your target language (e.g. Persian) and your source language
   (English is built in). Packs are ~30 MB each. Without a pack or an online provider nothing can be translated.
3. Pick source (Auto detect or a language) and target on the Translate tab, press **Start**, accept Android's capture
   dialog (on Android 14+ it is requested for the whole screen), then switch to the app or game.
4. The floating handle: tap to expand → pause/resume, hide/show labels, quick settings, stop.

## Architecture

```
capture/   CaptureEngine (MediaProjection → VirtualDisplay → ImageReader, pull model, resize on rotation)
           ChangeDetector (32×64 luma grid diff, ~8k pixel reads/frame), RegionPlanner (crop OCR to dirty area)
ocr/       OcrEngine interface, MlKitOcrEngine, ParagraphSplitter, OcrPostProcessor
track/     TextTracker: exact-text then fuzzy+geometry matching, typing (growth) detection, OCR-noise hysteresis
translate/ TranslationProvider (on-device ML Kit, Google Cloud v2, LibreTranslate), TranslationCoordinator
           (dedupe, obsolete-cancel, bounded queue, priority, debounce, batching, cooldowns, fallback), cache + Room memory
overlay/   OverlayView (one full-screen Canvas view, all animation), OverlayController, FloatingWidget,
           StyleSampler (bg/fg colour + weight), OverlayHostService (optional accessibility host)
service/   TranslationService (foreground, type mediaProjection), Pipeline (the loop), SessionHub (UI state)
ui/        Compose screens: onboarding, dashboard, settings, language picker, packs, online providers, apps, history
```

Each stage is independent and replaceable (`OcrEngine`, `TranslationProvider`). Pipeline state lives on one
single-threaded dispatcher, so there are no locks.

### The pipeline

1. Pull the newest frame (none arrives while the screen is static, so idle cost is near zero).
2. Compare a coarse luma grid with the previous frame, ignoring tiles under our own labels. Fewer than 3 changed tiles → skip.
3. Debounce, then OCR only the dirty region (grown to include any tracked text it touches), or the full frame after a scene cut.
4. Drop low-confidence/tiny/numeric/URL/vertical text, merge duplicates, split blocks into paragraphs.
5. Track across frames. Unchanged text is never re-translated; moved/scrolled text keeps its identity.
6. Translate: short labels first, newest first. Growing text (typing) gets provisional translations with a debounce, and a
   final one when it stops growing. Revisions re-type only the changed suffix.
7. Draw: label box matches the source rect, font size is fitted (binary search) near the original size, alignment is
   mirrored when reading direction flips, RTL is forced for RTL targets, fade+rise+typewriter animation, loading dots
   only if a translation is late, "…" dots while provisional.

### Adaptive behaviour

Sampling interval scales with measured OCR time, typing activity, battery ≤20% / Android battery saver / thermal
status, and the speed-vs-quality setting. Capture resolution is 1280/1600/2000 px on the long side. Animation drops
typing and motion automatically if frames run slow.

## Limitations (please read)

* **Our own overlay appears in the captured frames, and Android has no public way to exclude it.** Text hidden under a
  label therefore can't be re-read by normal scans. The pipeline handles it with *verification peeks*: it hides the
  affected labels, grabs a clean frame, restores them, then OCRs that area. Static text is re-checked rarely (interval
  backs off from 0.4 s to 6 s, or 12 s when nothing else on screen changed); text being typed is re-checked every
  ~350 ms. **During a peek the original text can flash for roughly 50–120 ms.** Typed dialogue will show this most.
  The timing constants (`PEEK_SETTLE_MS`, `PEEK_MIN_AGE_NS` in `Pipeline.kt`) are educated guesses and need tuning per device.
* **OCR script coverage is limited by ML Kit**: Latin scripts, Chinese, Japanese, Korean and Devanagari only. Persian,
  Arabic, Russian, Greek, Thai, Hebrew etc. work as *targets* but cannot be read as *sources*; the picker disables them
  as sources and says so. Swap in another `OcrEngine` (e.g. Tesseract with the right models) to extend this.
  "Auto detect" runs the Latin recogniser; choose Japanese/Chinese/Korean explicitly to read those.
* **Offline translation** covers the 59 ML Kit languages and only after packs are downloaded. Unlisted languages are not offered.
* **Touches under labels.** Android 12+ blocks taps through untrusted overlays more than 80% opaque. Without the optional
  accessibility helper the overlay window alpha is capped at 0.8 (slightly weaker concealment). With the helper enabled
  (Settings → Permissions), taps pass through at full opacity. "Strong concealment" opts out of the cap. The helper declares
  no event types and cannot read content, but Google Play restricts accessibility use, so keep that in mind if you publish.
* **Protected content.** FLAG_SECURE apps, DRM video and some system UI come out black; we show a notice and never try to
  get around it. Android 14+ lets users pick "one app" in the capture dialog; we request the full screen but can't force it.
* **Not implemented**: vertical text (skipped on purpose), motion compensation for fast scrolling (labels follow after
  the next scan rather than moving with the content), glossary editing UI (translation memory covers repeated labels;
  numbers, URLs and symbols are simply not translated), per-app rules without Usage Access.
* **Online providers need credentials you supply.** Keys are typed at runtime, stored in Keystore-backed encrypted
  storage, and never compiled into the app. For real deployments put a proxy you control in the "Proxy URL" field.
  Online use is off until the user explicitly agrees, and only extracted text is ever sent.

## Privacy

Frames live in memory only and are discarded after OCR. No screenshots are saved or uploaded. Translation history and
memory (text only) can be turned off and cleared in Settings → Privacy. The Stop button, the notification action and the
Android capture chip all end capture immediately; revoking the overlay permission also stops the session.

## Things to verify first on a device

1. Does the first build compile? (Likely small fixes in Compose/ML Kit API usage.)
2. Start → switch to a game. Do labels line up with the text? (Coordinate mapping uses real display size; check cutouts/rotation.)
3. Peek timing: if labels never refresh, raise `PEEK_SETTLE_MS`; if you see the original flash too long, lower it.
4. Typewriter + provisional translations on a visual-novel style dialogue box.
5. Rotation, split-screen and foldables (display listener resizes the virtual display).
6. Battery/thermal behaviour over a 10-minute session.
