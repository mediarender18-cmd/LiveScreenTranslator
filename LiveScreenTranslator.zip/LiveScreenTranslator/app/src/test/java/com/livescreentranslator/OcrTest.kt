package com.livescreentranslator

import com.livescreentranslator.core.FRect
import com.livescreentranslator.core.HAlign
import com.livescreentranslator.core.OcrUnit
import com.livescreentranslator.core.SelfLabel
import com.livescreentranslator.ocr.LineBox
import com.livescreentranslator.ocr.OcrPostProcessor
import com.livescreentranslator.ocr.ParagraphSplitter
import com.livescreentranslator.ocr.UnitBuilder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

private fun line(text: String, l: Float, t: Float, w: Float, h: Float = 30f, conf: Float = 0.9f) =
    LineBox(text, FRect(l, t, l + w, t + h), conf)

private fun unit(text: String, l: Float, t: Float, w: Float = 200f, h: Float = 30f, conf: Float = 0.9f) =
    OcrUnit(text, FRect(l, t, l + w, t + h), conf, 1, h, HAlign.LEFT)

class OcrTest {
    @Test fun stackedMenuEntriesStaySeparate() {
        val menu = listOf(line("Start", 100f, 100f, 100f), line("Options", 100f, 135f, 140f), line("Exit", 100f, 170f, 90f))
        val units = UnitBuilder.build(menu, 1080f)
        assertEquals(listOf("Start", "Options", "Exit"), units.map { it.text })
    }

    @Test fun wrappedDialogueIsOneParagraph() {
        val dialogue = listOf(
            line("I think we should go to the", 50f, 500f, 600f),
            line("market tomorrow before it rains", 50f, 534f, 560f),
            line("and the shops close.", 50f, 568f, 300f),
        )
        val units = UnitBuilder.build(dialogue, 1080f)
        assertEquals(1, units.size)
        assertEquals("I think we should go to the market tomorrow before it rains and the shops close.", units[0].text)
        assertEquals(3, units[0].lineCount)
        assertEquals(FRect(50f, 500f, 650f, 598f), units[0].rect)
    }

    @Test fun cjkLinesJoinWithoutSpaces() {
        val l = listOf(line("今日はいい", 50f, 100f, 300f), line("天気ですね", 50f, 134f, 250f))
        assertEquals("今日はいい天気ですね", UnitBuilder.build(l, 1080f)[0].text)
    }

    @Test fun alignmentIsEstimatedFromLineEdges() {
        val centered = listOf(FRect(100f, 0f, 300f, 20f), FRect(150f, 25f, 250f, 45f))
        assertEquals(HAlign.CENTER, UnitBuilder.alignOf(centered, 1000f))
        val left = listOf(FRect(100f, 0f, 300f, 20f), FRect(100f, 25f, 250f, 45f))
        assertEquals(HAlign.LEFT, UnitBuilder.alignOf(left, 1000f))
        val right = listOf(FRect(100f, 0f, 300f, 20f), FRect(200f, 25f, 300f, 45f))
        assertEquals(HAlign.RIGHT, UnitBuilder.alignOf(right, 1000f))
    }

    @Test fun singleCentredLineIsCentred() {
        assertEquals(HAlign.CENTER, UnitBuilder.alignOf(listOf(FRect(400f, 0f, 600f, 20f)), 1000f))
    }

    @Test fun verticalTextIsFlagged() {
        val u = UnitBuilder.build(listOf(line("縦書き", 10f, 10f, 20f, 100f)), 1000f)[0]
        assertTrue(u.vertical)
    }

    @Test fun postProcessorDropsNoiseAndNonText() {
        val p = OcrPostProcessor(0.5f)
        val out = p.process(
            listOf(
                unit("OPTIONS", 10f, 10f), unit("12345", 10f, 60f), unit("blurry", 10f, 110f, conf = 0.2f),
                unit("tiny", 10f, 160f, h = 4f), unit("https://x.io", 10f, 210f),
            ),
            1080, 1920, emptyList(),
        )
        assertEquals(listOf("OPTIONS"), out.map { it.text })
    }

    @Test fun postProcessorSuppressesOurOwnLabels() {
        val p = OcrPostProcessor(0.5f)
        val own = SelfLabel(FRect(0f, 0f, 300f, 60f))
        val out = p.process(listOf(unit("گزینه ها", 20f, 10f), unit("Real text", 20f, 400f)), 1080, 1920, listOf(own))
        assertEquals(listOf("Real text"), out.map { it.text })
    }

    @Test fun postProcessorMergesDuplicates() {
        val p = OcrPostProcessor(0.5f)
        val out = p.process(listOf(unit("Play", 10f, 10f, conf = 0.7f), unit("Play", 11f, 10f, conf = 0.9f)), 1080, 1920, emptyList())
        assertEquals(1, out.size)
        assertEquals(0.9f, out[0].confidence, 1e-6f)
    }
}
