package com.livescreentranslator

import com.livescreentranslator.capture.GridMath
import com.livescreentranslator.capture.RegionPlanner
import com.livescreentranslator.core.FRect
import com.livescreentranslator.overlay.RevealMath
import com.livescreentranslator.overlay.StyleSampler
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChangeDetectionTest {
    private val cols = 4
    private val rows = 4

    @Test fun identicalGridsHaveNoChange() {
        val g = IntArray(16) { 100 }
        val d = GridMath.diff(g, g.copyOf(), cols, rows, 10, null)
        assertEquals(0, d.changed); assertEquals(16, d.considered)
    }

    @Test fun changedTilesProduceBoundingBox() {
        val a = IntArray(16) { 100 }
        val b = a.copyOf().also { it[1 * 4 + 1] = 200; it[2 * 4 + 2] = 40 }
        val d = GridMath.diff(a, b, cols, rows, 10, null)
        assertEquals(2, d.changed)
        assertEquals(1, d.minC); assertEquals(2, d.maxC); assertEquals(1, d.minR); assertEquals(2, d.maxR)
    }

    @Test fun smallLumaNoiseIsBelowThreshold() {
        val a = IntArray(16) { 100 }
        val b = IntArray(16) { 105 }
        assertEquals(0, GridMath.diff(a, b, cols, rows, 10, null).changed)
    }

    @Test fun tilesUnderOurOverlayAreIgnored() {
        val a = IntArray(16) { 100 }
        val b = a.copyOf().also { it[0] = 255 }
        val mask = GridMath.ignoreMask(listOf(FRect(0f, 0f, 100f, 100f)), cols, rows, 400f, 400f)
        assertTrue(mask[0]); assertFalse(mask[5])
        val d = GridMath.diff(a, b, cols, rows, 10, mask)
        assertEquals(0, d.changed)
        assertEquals(15, d.considered)
    }

    @Test fun blankFrameIsDetected() {
        assertTrue(GridMath.isBlank(IntArray(16) { 0 }))
        assertFalse(GridMath.isBlank(IntArray(16) { if (it == 3) 200 else 0 }))
    }

    @Test fun smallDirtyAreaGetsACropThatCoversTouchedText() {
        val dirty = FRect(100f, 100f, 200f, 140f)
        val text = FRect(150f, 120f, 600f, 160f)   // touches the dirty box, extends well beyond it
        val region = RegionPlanner.plan(dirty, listOf(text), 1080f, 1920f)
        assertNotNull(region)
        assertTrue(region!!.right >= 600f)
        assertTrue(region.area < 0.55f * 1080f * 1920f)
    }

    @Test fun largeDirtyAreaFallsBackToFullFrame() {
        assertNull(RegionPlanner.plan(FRect(0f, 0f, 1000f, 1500f), emptyList(), 1080f, 1920f))
    }

    @Test fun cropIsClampedToTheFrame() {
        val r = RegionPlanner.plan(FRect(0f, 0f, 50f, 50f), emptyList(), 1080f, 1920f)!!
        assertEquals(0f, r.left, 0f); assertEquals(0f, r.top, 0f)
    }
}

class StyleSamplerTest {
    private val white = 0xFFFFFFFF.toInt()
    private val black = 0xFF000000.toInt()

    @Test fun darkTextOnLightBackground() {
        val inner = IntArray(100) { if (it % 10 == 0) black else white }
        val s = StyleSampler.analyze(IntArray(20) { white }, inner)
        assertEquals(white, s.bg)
        assertTrue(StyleSampler.luminance(s.fg) < 0.2f)
        assertFalse(s.bold)
    }

    @Test fun lightTextOnDarkBackground() {
        val bg = 0xFF101820.toInt()
        val inner = IntArray(100) { if (it % 8 == 0) white else bg }
        val s = StyleSampler.analyze(IntArray(20) { bg }, inner)
        assertEquals(bg, s.bg)
        assertTrue(StyleSampler.luminance(s.fg) > 0.8f)
    }

    @Test fun heavyInkMeansBold() {
        val inner = IntArray(100) { if (it % 3 != 0) black else white }
        assertTrue(StyleSampler.analyze(IntArray(20) { white }, inner).bold)
    }

    @Test fun lowContrastForegroundIsCorrected() {
        val bg = 0xFF808080.toInt()
        val faint = 0xFF8A8A8A.toInt()
        val s = StyleSampler.analyze(IntArray(10) { bg }, IntArray(50) { if (it % 2 == 0) faint else bg })
        assertTrue(Math.abs(StyleSampler.luminance(s.fg) - StyleSampler.luminance(s.bg)) >= 0.35f)
    }
}

class RevealMathTest {
    @Test fun breaksCoverWholeString() {
        assertArrayEquals(intArrayOf(0, 1, 2, 3), RevealMath.breaks("abc"))
        assertArrayEquals(intArrayOf(0), RevealMath.breaks(""))
    }

    @Test fun surrogatePairsAreNotSplit() {
        val s = "a😀b"
        val b = RevealMath.breaks(s)
        assertEquals(listOf(0, 1, 3, 4), b.toList())
    }

    @Test fun commonPrefixKeepsAlreadyShownWords() {
        assertEquals(5, RevealMath.commonPrefixGraphemes("Hello", "Hello world"))
        assertEquals(3, RevealMath.commonPrefixGraphemes("Helmet", "Help me"))
        assertEquals(0, RevealMath.commonPrefixGraphemes("abc", "xyz"))
    }

    @Test fun persianRevisionRewritesOnlyChangedSuffix() {
        val old = "گزینه"
        val new = "گزینه‌ها"           // the translation gained a suffix after more context arrived
        // Depending on how the JDK clusters the zero-width joiner, the last letter may or may not count as shared.
        val shared = RevealMath.commonPrefixGraphemes(old, new)
        assertTrue(shared in (RevealMath.breaks(old).size - 2)..(RevealMath.breaks(old).size - 1))
    }

    @Test fun longTextRevealsInAboutOneSecond() {
        assertEquals(45f, RevealMath.charsPerSecond(10, 1f), 1e-4f)
        assertEquals(100f, RevealMath.charsPerSecond(100, 1f), 1e-4f)
        assertEquals(220f, RevealMath.charsPerSecond(1000, 1f), 1e-4f)
        assertEquals(90f, RevealMath.charsPerSecond(10, 2f), 1e-4f)
    }
}
