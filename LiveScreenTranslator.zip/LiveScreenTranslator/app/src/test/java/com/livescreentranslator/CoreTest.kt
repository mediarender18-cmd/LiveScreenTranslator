package com.livescreentranslator

import com.livescreentranslator.core.CoordinateMapper
import com.livescreentranslator.core.FRect
import com.livescreentranslator.core.TextUtil
import com.livescreentranslator.data.Languages
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GeometryTest {
    @Test fun iouOfIdenticalIsOne() = assertEquals(1f, FRect(0f, 0f, 10f, 10f).iou(FRect(0f, 0f, 10f, 10f)), 1e-6f)

    @Test fun iouOfDisjointIsZero() = assertEquals(0f, FRect(0f, 0f, 10f, 10f).iou(FRect(20f, 20f, 30f, 30f)), 1e-6f)

    @Test fun iouHalfOverlap() = assertEquals(1f / 3f, FRect(0f, 0f, 10f, 10f).iou(FRect(5f, 0f, 15f, 10f)), 1e-4f)

    @Test fun unionAndInflate() {
        val u = FRect(0f, 0f, 10f, 10f).union(FRect(5f, 5f, 20f, 8f))
        assertEquals(FRect(0f, 0f, 20f, 10f), u)
        assertEquals(FRect(-2f, -2f, 12f, 12f), FRect(0f, 0f, 10f, 10f).inflate(2f))
    }

    @Test fun clampKeepsRectInsideFrame() {
        assertEquals(FRect(0f, 0f, 100f, 50f), FRect(-5f, -5f, 120f, 70f).clamp(100f, 50f))
    }

    @Test fun mapperScalesFrameToScreen() {
        val m = CoordinateMapper(srcW = 800, srcH = 400, dstW = 1600, dstH = 800)
        assertEquals(FRect(20f, 40f, 220f, 140f), m.map(FRect(10f, 20f, 110f, 70f)))
    }

    @Test fun mapperRoundTripsWithOrigin() {
        val m = CoordinateMapper(720, 1560, 1080, 2340, originX = 0f, originY = 63f)
        val r = FRect(100f, 200f, 300f, 260f)
        val back = m.unmap(m.map(r))
        assertEquals(r.left, back.left, 1e-3f); assertEquals(r.top, back.top, 1e-3f)
        assertEquals(r.right, back.right, 1e-3f); assertEquals(r.bottom, back.bottom, 1e-3f)
    }

    @Test fun mapperHandlesRotatedFrame() {
        // Portrait capture 540x1200 shown on a 1080x2400 screen: uniform 2x scale.
        val m = CoordinateMapper(540, 1200, 1080, 2400)
        assertEquals(2f, m.scaleX, 1e-6f); assertEquals(2f, m.scaleY, 1e-6f)
    }
}

class TextUtilTest {
    @Test fun similarityBasics() {
        assertEquals(1f, TextUtil.similarity("abc", "abc"), 0f)
        assertEquals(0f, TextUtil.similarity("abc", "xyz"), 0f)
        assertTrue(TextUtil.similarity("OPTIONS", "OPTIQNS") > 0.85f)
    }

    @Test fun growthDetectsTypedText() {
        assertTrue(TextUtil.isGrowth("Hello", "Hello wor"))
        assertTrue(TextUtil.isGrowth("Hello wor", "Hello world"))
        assertFalse(TextUtil.isGrowth("Hello", "Hello"))
        assertFalse(TextUtil.isGrowth("Hello world", "Hello"))
        assertFalse(TextUtil.isGrowth("Start", "Resume game"))
    }

    @Test fun shouldTranslateFiltersNonText() {
        assertTrue(TextUtil.shouldTranslate("OPTIONS"))
        assertTrue(TextUtil.shouldTranslate("Press any key"))
        assertTrue(TextUtil.shouldTranslate("開始"))
        assertFalse(TextUtil.shouldTranslate("12345"))
        assertFalse(TextUtil.shouldTranslate("HP 100"))
        assertFalse(TextUtil.shouldTranslate("x"))
        assertFalse(TextUtil.shouldTranslate("https://example.com/a"))
        assertFalse(TextUtil.shouldTranslate("  "))
    }

    @Test fun normalizeCollapsesWhitespace() = assertEquals("a b c", TextUtil.normalize("  a \n b   c "))
}

class LanguagesTest {
    @Test fun persianIsRtlTarget() {
        assertTrue(Languages.isRtl("fa"))
        assertTrue(Languages.isRtl("ar"))
        assertFalse(Languages.isRtl("en"))
    }

    @Test fun ocrSupportIsHonest() {
        assertNotNull(Languages.byCode["ja"]?.ocr)
        assertNull(Languages.byCode["fa"]?.ocr)   // Persian can be a target, but not read by on-device OCR
        assertNull(Languages.byCode["ru"]?.ocr)
    }

    @Test fun requiredLanguagesPresent() {
        for (c in listOf("fa", "en", "ar", "es", "fr", "de", "ja", "ko", "zh", "ru", "tr")) assertTrue(c, Languages.byCode.containsKey(c))
    }

    @Test fun searchMatchesNativeAndEnglishNames() {
        assertTrue(Languages.search("pers", true).any { it.code == "fa" })
        assertTrue(Languages.search("فارسی", true).any { it.code == "fa" })
        assertTrue(Languages.search("de", true).any { it.code == "de" })
    }
}
