package com.livescreentranslator

import com.livescreentranslator.translate.ErrorKind
import com.livescreentranslator.translate.LangPair
import com.livescreentranslator.translate.TranslationCache
import com.livescreentranslator.translate.TranslationCoordinator
import com.livescreentranslator.translate.TranslationException
import com.livescreentranslator.translate.TranslationProvider
import com.livescreentranslator.translate.TranslationRequest
import com.livescreentranslator.translate.TranslationResult
import com.livescreentranslator.translate.TranslationStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.CopyOnWriteArrayList

private class FakeProvider(
    override val id: String = "fake",
    override val displayName: String = "Fake",
    private val failWith: ErrorKind? = null,
) : TranslationProvider {
    override val sendsTextOffDevice = false
    val calls = CopyOnWriteArrayList<List<String>>()
    override suspend fun translate(texts: List<String>, src: String, tgt: String): List<String> {
        calls += texts
        failWith?.let { throw TranslationException(it, "fake failure") }
        return texts.map { "$tgt:$it" }
    }
}

private class MemoryStore : TranslationStore {
    val saved = HashMap<String, String>()
    override suspend fun find(src: String, tgt: String, text: String) = saved["$src|$tgt|$text"]
    override suspend fun save(src: String, tgt: String, text: String, out: String, engine: String) { saved["$src|$tgt|$text"] = out }
}

class CoordinatorTest {
    private val scope = CoroutineScope(Dispatchers.Default + Job())
    @After fun tearDown() = scope.cancel()

    private fun make(
        vararg providers: TranslationProvider, pair: LangPair = LangPair("en", "fa"),
        detect: suspend (String) -> String? = { null }, store: TranslationStore? = null,
    ) = TranslationCoordinator(scope, { providers.toList() }, { pair }, detect, TranslationCache(store)).also { it.start() }

    private suspend fun TranslationCoordinator.next(): TranslationResult = withTimeout(3000) { results.receive() }
    private suspend fun TranslationCoordinator.nothingMore(ms: Long = 350) = assertNull(withTimeoutOrNull(ms) { results.receive() })

    @Test fun translatesAndTagsResultWithTrackAndVersion() = runBlocking {
        val p = FakeProvider()
        val c = make(p)
        c.submit(TranslationRequest(7, 3, "OPTIONS", false, 3))
        val r = c.next()
        assertEquals(7L, r.trackId); assertEquals(3, r.version)
        assertEquals("fa:OPTIONS", r.translated)
        assertEquals("Fake", r.engine)
    }

    @Test fun identicalTextFromSeveralTracksIsTranslatedOnce() = runBlocking {
        val p = FakeProvider()
        val c = make(p)
        c.submit(TranslationRequest(1, 0, "Start", false, 3, delayMs = 120))
        c.submit(TranslationRequest(2, 0, "Start", false, 3, delayMs = 120))
        val got = listOf(c.next(), c.next())
        assertEquals(setOf(1L, 2L), got.map { it.trackId }.toSet())
        assertEquals(1, p.calls.size)
        assertEquals(listOf("Start"), p.calls[0])
    }

    @Test fun newerVersionSupersedesQueuedOlderOne() = runBlocking {
        val p = FakeProvider()
        val c = make(p)
        c.submit(TranslationRequest(1, 0, "Hel", true, 2, delayMs = 200))
        c.submit(TranslationRequest(1, 1, "Hello", false, 2, delayMs = 0))
        val r = c.next()
        assertEquals(1, r.version); assertEquals("fa:Hello", r.translated)
        c.nothingMore(500)
        assertEquals(listOf(listOf("Hello")), p.calls.toList())
    }

    @Test fun repeatedTextIsServedFromCacheWithoutProviderCall() = runBlocking {
        val p = FakeProvider()
        val c = make(p)
        c.submit(TranslationRequest(1, 0, "Continue", false, 3)); c.next()
        c.submit(TranslationRequest(2, 0, "Continue", false, 3))
        val r = c.next()
        assertTrue(r.fromCache); assertEquals("fa:Continue", r.translated)
        assertEquals(1, p.calls.size)
    }

    @Test fun translationMemorySurvivesAcrossSessions() = runBlocking {
        val store = MemoryStore()
        val first = make(FakeProvider(), store = store)
        first.submit(TranslationRequest(1, 0, "Settings", false, 3)); first.next()
        assertEquals("fa:Settings", store.saved["en|fa|Settings"])
        val p2 = FakeProvider()
        val second = make(p2, store = store)
        second.submit(TranslationRequest(1, 0, "Settings", false, 3))
        assertTrue(second.next().fromCache)
        assertTrue(p2.calls.isEmpty())
    }

    @Test fun fallsBackToNextProviderOnFailure() = runBlocking {
        val bad = FakeProvider("bad", "Bad", failWith = ErrorKind.NETWORK)
        val good = FakeProvider("good", "Good")
        val c = make(bad, good)
        c.submit(TranslationRequest(1, 0, "Quit", false, 3))
        val r = c.next()
        assertEquals("fa:Quit", r.translated); assertEquals("Good", r.engine)
        assertEquals(1, bad.calls.size)
    }

    @Test fun reportsErrorKindWhenEverythingFails() = runBlocking {
        val c = make(FakeProvider(failWith = ErrorKind.MODEL_MISSING))
        c.submit(TranslationRequest(1, 0, "Quit", false, 3))
        val r = c.next()
        assertNull(r.translated)
        assertEquals(ErrorKind.MODEL_MISSING, r.error)
        assertFalse(c.status.value.ok)
        assertTrue(c.status.value.label.contains("Offline pack"))
    }

    @Test fun rateLimitedProviderIsCooledDownNotHammered() = runBlocking {
        val limited = FakeProvider("lim", "Lim", failWith = ErrorKind.RATE_LIMIT)
        val c = make(limited)
        c.submit(TranslationRequest(1, 0, "One", false, 3)); c.next()
        c.submit(TranslationRequest(2, 0, "Two", false, 3)); c.next()
        assertEquals(1, limited.calls.size)   // second request never reached the provider
    }

    @Test fun sameSourceAndTargetIsSkipped() = runBlocking {
        val p = FakeProvider()
        val c = make(p, pair = LangPair("fa", "fa"))
        c.submit(TranslationRequest(1, 0, "سلام", false, 3))
        val r = c.next()
        assertTrue(r.sameLanguage); assertNull(r.translated)
        assertTrue(p.calls.isEmpty())
    }

    @Test fun autoDetectUsesDetectedSourceAndSkipsTargetLanguageText() = runBlocking {
        val p = FakeProvider()
        val c = make(p, pair = LangPair("auto", "fa"), detect = { if (it == "سلام") "fa" else "en" })
        c.submit(TranslationRequest(1, 0, "سلام", false, 3))
        assertTrue(c.next().sameLanguage)
        c.submit(TranslationRequest(2, 0, "Hello", false, 3))
        val r = c.next()
        assertEquals("en", r.srcLang); assertEquals("fa:Hello", r.translated)
    }

    @Test fun cancelledTrackProducesNoResult() = runBlocking {
        val p = FakeProvider()
        val c = make(p)
        c.submit(TranslationRequest(1, 0, "Soon gone", false, 1, delayMs = 150))
        c.cancel(1)
        c.nothingMore(500)
        assertTrue(p.calls.isEmpty())
    }

    @Test fun shortLabelsAreTranslatedBeforeLongParagraphs() = runBlocking {
        val p = FakeProvider()
        val c = TranslationCoordinator(scope, { listOf(p) }, { LangPair("en", "fa") }, { null }, TranslationCache(null), maxBatch = 1)
        c.submit(TranslationRequest(1, 0, "A long paragraph of dialogue text", false, 1, delayMs = 100))
        c.submit(TranslationRequest(2, 0, "OK", false, 3, delayMs = 100))
        c.start()
        assertEquals(2L, c.next().trackId)
    }
}
