package com.livescreentranslator

import com.livescreentranslator.core.FRect
import com.livescreentranslator.core.HAlign
import com.livescreentranslator.core.OcrUnit
import com.livescreentranslator.track.ChangeKind
import com.livescreentranslator.track.TextTracker
import com.livescreentranslator.track.TrackState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

private fun u(text: String, l: Float, t: Float, w: Float = 200f, h: Float = 30f) =
    OcrUnit(text, FRect(l, t, l + w, t + h), 0.9f, 1, h, HAlign.LEFT)

private val FULL = FRect(0f, 0f, 1080f, 1920f)

class TrackerTest {
    private fun TextTracker.step(now: Long, vararg us: OcrUnit, scan: FRect = FULL, fast: Boolean = false) =
        update(us.toList(), now, scan, 1080f, 1920f, fast)

    @Test fun unchangedTextIsNotRetranslated() {
        val t = TextTracker()
        val d1 = t.step(0, u("OPTIONS", 100f, 100f))
        assertEquals(1, d1.added.size)
        val id = d1.added[0].id
        val d2 = t.step(200, u("OPTIONS", 100f, 100f))
        assertTrue(d2.added.isEmpty()); assertTrue(d2.changed.isEmpty()); assertTrue(d2.removed.isEmpty())
        assertEquals(id, t.tracks[0].id)
        assertEquals(0, t.tracks[0].textVersion)
    }

    @Test fun movementKeepsIdentity() {
        val t = TextTracker()
        val id = t.step(0, u("Score", 100f, 100f)).added[0].id
        val d = t.step(100, u("Score", 130f, 100f))
        assertEquals(1, d.changed.size)
        assertEquals(ChangeKind.MOVED, d.changed[0].second)
        assertEquals(id, d.changed[0].first.id)
        assertEquals(0, d.changed[0].first.textVersion)
    }

    @Test fun typedTextIsTrackedAsGrowthThenSettles() {
        val t = TextTracker(settleMs = 450)
        val id = t.step(0, u("Hello", 50f, 500f, w = 120f)).added[0].id
        val d = t.step(100, u("Hello wor", 50f, 500f, w = 200f))
        assertEquals(ChangeKind.GROWING, d.changed[0].second)
        assertEquals(id, d.changed[0].first.id)
        assertEquals(TrackState.TYPING, t.get(id)!!.state)
        t.step(200, u("Hello world", 50f, 500f, w = 250f))
        assertEquals(2, t.get(id)!!.textVersion)
        assertTrue(t.settle(300).isEmpty())          // still typing
        val settled = t.settle(700)
        assertEquals(1, settled.size)
        assertEquals(TrackState.STABLE, t.get(id)!!.state)
    }

    @Test fun inPlaceReplacementBumpsVersion() {
        val t = TextTracker()
        val id = t.step(0, u("Start", 100f, 100f)).added[0].id
        val d = t.step(100, u("Resume", 100f, 100f))
        assertEquals(ChangeKind.REPLACED, d.changed[0].second)
        assertEquals(id, d.changed[0].first.id)
        assertEquals(1, t.get(id)!!.textVersion)
    }

    @Test fun ocrJitterDoesNotTriggerRetranslation() {
        val t = TextTracker()
        t.step(0, u("OPTIONS", 100f, 100f))
        val d = t.step(100, u("OPTIQNS", 100f, 100f))
        assertTrue(d.changed.isEmpty())
        assertEquals("OPTIONS", t.tracks[0].text)
    }

    @Test fun changedDigitsAlwaysCount() {
        val t = TextTracker()
        t.step(0, u("Level 2", 100f, 100f))
        val d = t.step(100, u("Level 3", 100f, 100f))
        assertEquals(ChangeKind.REPLACED, d.changed[0].second)
    }

    @Test fun scrollingListKeepsEveryRowIdentity() {
        val t = TextTracker()
        val d = t.step(0, u("Item Alpha", 100f, 600f), u("Item Beta", 100f, 700f), u("Item Gamma", 100f, 800f))
        val ids = d.added.associate { it.text to it.id }
        val d2 = t.step(100, u("Item Alpha", 100f, 520f), u("Item Beta", 100f, 620f), u("Item Gamma", 100f, 720f))
        assertTrue(d2.added.isEmpty() && d2.removed.isEmpty())
        assertEquals(3, d2.changed.size)
        for ((tr, k) in d2.changed) { assertEquals(ChangeKind.MOVED, k); assertEquals(ids[tr.text], tr.id) }
    }

    @Test fun twoIdenticalButtonsMatchTheNearestOne() {
        val t = TextTracker()
        val d = t.step(0, u("OK", 100f, 100f), u("OK", 100f, 900f))
        val top = d.added.first { it.rect.top < 500f }.id
        val bottom = d.added.first { it.rect.top > 500f }.id
        t.step(100, u("OK", 100f, 880f), u("OK", 100f, 95f))
        assertEquals(95f, t.get(top)!!.rect.top, 1e-3f)
        assertEquals(880f, t.get(bottom)!!.rect.top, 1e-3f)
    }

    @Test fun missingTextExpiresAfterTwoScans() {
        val t = TextTracker()
        t.step(0, u("Gone", 100f, 100f))
        assertTrue(t.step(100).removed.isEmpty())
        assertEquals(1, t.step(200).removed.size)
        assertTrue(t.tracks.isEmpty())
    }

    @Test fun sceneCutExpiresImmediately() {
        val t = TextTracker()
        t.step(0, u("Gone", 100f, 100f))
        assertEquals(1, t.step(100, fast = true).removed.size)
    }

    @Test fun textHiddenUnderOurLabelIsNeverCountedAsMissing() {
        val t = TextTracker()
        val tr = t.step(0, u("Covered", 100f, 100f)).added[0]
        tr.covered = true
        repeat(5) { t.step(100L * (it + 1)) }
        assertNotNull(t.get(tr.id))
    }

    @Test fun onlyTracksInsideScannedRegionCanExpire() {
        val t = TextTracker()
        t.step(0, u("Top", 100f, 100f), u("Bottom", 100f, 1500f))
        val partial = FRect(0f, 1400f, 1080f, 1920f)
        t.step(100, scan = partial)
        t.step(200, scan = partial)
        assertEquals(listOf("Top"), t.tracks.map { it.text })
    }
}
