package com.livescreentranslator.data

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

enum class EngineChoice { AUTO, OFFLINE, GOOGLE, LIBRE }
enum class ConcealMode { ADAPTIVE, BLACK, BORDERLESS }
enum class QualityPref { LATENCY, BALANCED, QUALITY }
enum class ThemeChoice { DARK, LIGHT, SYSTEM }

data class AppSettings(
    val source: String = Languages.AUTO,
    val target: String = Languages.defaultTarget(),
    val engine: EngineChoice = EngineChoice.AUTO,
    val conceal: ConcealMode = ConcealMode.ADAPTIVE,
    val bgOpacity: Float = 0.92f,
    val textScale: Float = 1f,
    val animSpeed: Float = 1f,
    val typing: Boolean = true,
    val quality: QualityPref = QualityPref.BALANCED,
    val batterySaver: Boolean = false,
    val excludedApps: Set<String> = emptySet(),
    val keepHistory: Boolean = true,
    val onboardingDone: Boolean = false,
    val theme: ThemeChoice = ThemeChoice.DARK,
    val wifiOnlyPacks: Boolean = true,
    /** The user explicitly agreed that extracted text may be sent to the online provider they configured. */
    val onlineConsent: Boolean = false,
    /** Optional override, e.g. your own backend proxy that holds the real provider credentials. */
    val googleEndpoint: String = "",
    val libreEndpoint: String = "",
    /** On Android 12+ without the accessibility host, true = fully opaque labels that block taps beneath them. */
    val strongConceal: Boolean = false,
)

private val Context.dataStore by preferencesDataStore(name = "settings")

private object K {
    val source = stringPreferencesKey("source")
    val target = stringPreferencesKey("target")
    val engine = stringPreferencesKey("engine")
    val conceal = stringPreferencesKey("conceal")
    val bgOpacity = floatPreferencesKey("bg_opacity")
    val textScale = floatPreferencesKey("text_scale")
    val animSpeed = floatPreferencesKey("anim_speed")
    val typing = booleanPreferencesKey("typing")
    val quality = stringPreferencesKey("quality")
    val batterySaver = booleanPreferencesKey("battery_saver")
    val excluded = stringSetPreferencesKey("excluded_apps")
    val keepHistory = booleanPreferencesKey("keep_history")
    val onboarding = booleanPreferencesKey("onboarding_done")
    val theme = stringPreferencesKey("theme")
    val wifiOnly = booleanPreferencesKey("wifi_only_packs")
    val consent = booleanPreferencesKey("online_consent")
    val googleEndpoint = stringPreferencesKey("google_endpoint")
    val libreEndpoint = stringPreferencesKey("libre_endpoint")
    val strong = booleanPreferencesKey("strong_conceal")
}

private inline fun <reified E : Enum<E>> Preferences.enum(key: Preferences.Key<String>, default: E): E =
    get(key)?.let { s -> enumValues<E>().firstOrNull { it.name == s } } ?: default

private fun Preferences.toSettings(): AppSettings {
    val d = AppSettings()
    return AppSettings(
        source = this[K.source] ?: d.source,
        target = this[K.target] ?: d.target,
        engine = enum(K.engine, d.engine),
        conceal = enum(K.conceal, d.conceal),
        bgOpacity = this[K.bgOpacity] ?: d.bgOpacity,
        textScale = this[K.textScale] ?: d.textScale,
        animSpeed = this[K.animSpeed] ?: d.animSpeed,
        typing = this[K.typing] ?: d.typing,
        quality = enum(K.quality, d.quality),
        batterySaver = this[K.batterySaver] ?: d.batterySaver,
        excludedApps = this[K.excluded] ?: d.excludedApps,
        keepHistory = this[K.keepHistory] ?: d.keepHistory,
        onboardingDone = this[K.onboarding] ?: d.onboardingDone,
        theme = enum(K.theme, d.theme),
        wifiOnlyPacks = this[K.wifiOnly] ?: d.wifiOnlyPacks,
        onlineConsent = this[K.consent] ?: d.onlineConsent,
        googleEndpoint = this[K.googleEndpoint] ?: d.googleEndpoint,
        libreEndpoint = this[K.libreEndpoint] ?: d.libreEndpoint,
        strongConceal = this[K.strong] ?: d.strongConceal,
    )
}

private fun MutablePreferences.write(s: AppSettings) {
    this[K.source] = s.source
    this[K.target] = s.target
    this[K.engine] = s.engine.name
    this[K.conceal] = s.conceal.name
    this[K.bgOpacity] = s.bgOpacity
    this[K.textScale] = s.textScale
    this[K.animSpeed] = s.animSpeed
    this[K.typing] = s.typing
    this[K.quality] = s.quality.name
    this[K.batterySaver] = s.batterySaver
    this[K.excluded] = s.excludedApps
    this[K.keepHistory] = s.keepHistory
    this[K.onboarding] = s.onboardingDone
    this[K.theme] = s.theme.name
    this[K.wifiOnly] = s.wifiOnlyPacks
    this[K.consent] = s.onlineConsent
    this[K.googleEndpoint] = s.googleEndpoint
    this[K.libreEndpoint] = s.libreEndpoint
    this[K.strong] = s.strongConceal
}

class SettingsRepository(private val ctx: Context) {
    val flow: Flow<AppSettings> = ctx.dataStore.data.map { it.toSettings() }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        ctx.dataStore.edit { p -> p.write(transform(p.toSettings())) }
    }
}
