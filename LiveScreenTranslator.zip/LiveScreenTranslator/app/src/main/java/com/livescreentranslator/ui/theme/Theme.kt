package com.livescreentranslator.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.livescreentranslator.data.ThemeChoice

val Blue = Color(0xFF4C8DFF)
val Violet = Color(0xFF8B5CF6)
val Cyan = Color(0xFF22D3EE)
val Danger = Color(0xFFFF5C7A)
val Good = Color(0xFF3DDC97)

val AccentBrush = Brush.linearGradient(listOf(Blue, Violet, Cyan))

private val DarkScheme = darkColorScheme(
    primary = Blue, secondary = Violet, tertiary = Cyan,
    background = Color.Black, surface = Color(0xFF0A0B12), surfaceVariant = Color(0xFF14151F),
    onBackground = Color(0xFFEDEFFF), onSurface = Color(0xFFEDEFFF), onSurfaceVariant = Color(0xFF9AA0B8),
    outline = Color(0xFF2A2C3C), error = Danger,
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF2F6FE0), secondary = Color(0xFF6D3FE0), tertiary = Color(0xFF0B9FB8),
    background = Color(0xFFF5F6FB), surface = Color.White, surfaceVariant = Color(0xFFE9EBF5),
    onBackground = Color(0xFF0B0C14), onSurface = Color(0xFF0B0C14), onSurfaceVariant = Color(0xFF555B73),
    outline = Color(0xFFD0D3E2), error = Color(0xFFD6334F),
)

private val Base = FontFamily.SansSerif
private val AppTypography = Typography(
    headlineLarge = TextStyle(fontFamily = Base, fontWeight = FontWeight.Bold, fontSize = 30.sp, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontFamily = Base, fontWeight = FontWeight.SemiBold, fontSize = 24.sp, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontFamily = Base, fontWeight = FontWeight.SemiBold, fontSize = 20.sp),
    titleMedium = TextStyle(fontFamily = Base, fontWeight = FontWeight.Medium, fontSize = 16.sp),
    bodyLarge = TextStyle(fontFamily = Base, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = Base, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = Base, fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontFamily = Base, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, letterSpacing = 0.2.sp),
    labelSmall = TextStyle(fontFamily = Base, fontWeight = FontWeight.Medium, fontSize = 11.sp, letterSpacing = 0.6.sp),
)

@Composable
fun LstTheme(choice: ThemeChoice, content: @Composable () -> Unit) {
    val dark = when (choice) {
        ThemeChoice.DARK -> true
        ThemeChoice.LIGHT -> false
        ThemeChoice.SYSTEM -> isSystemInDarkTheme()
    }
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, typography = AppTypography, content = content)
}
