package com.livescreentranslator.capture

import com.livescreentranslator.core.FRect
import java.nio.ByteBuffer

data class GridDiff(
    val changed: Int, val considered: Int,
    val minC: Int, val maxC: Int, val minR: Int, val maxR: Int,
) {
    val ratio: Float get() = if (considered == 0) 0f else changed.toFloat() / considered
}

/** Pure grid maths, kept separate from Android types so it can be unit-tested. */
object GridMath {
    fun diff(prev: IntArray, cur: IntArray, cols: Int, rows: Int, threshold: Int, ignore: BooleanArray?): GridDiff {
        var changed = 0
        var considered = 0
        var minC = Int.MAX_VALUE; var maxC = -1; var minR = Int.MAX_VALUE; var maxR = -1
        for (r in 0 until rows) for (c in 0 until cols) {
            val i = r * cols + c
            if (ignore != null && ignore[i]) continue
            considered++
            if (kotlin.math.abs(prev[i] - cur[i]) > threshold) {
                changed++
                if (c < minC) minC = c
                if (c > maxC) maxC = c
                if (r < minR) minR = r
                if (r > maxR) maxR = r
            }
        }
        return GridDiff(changed, considered, minC, maxC, minR, maxR)
    }

    /** Marks grid tiles whose centre lies inside any of [rects] (frame coordinates). */
    fun ignoreMask(rects: List<FRect>, cols: Int, rows: Int, w: Float, h: Float): BooleanArray {
        val mask = BooleanArray(cols * rows)
        if (rects.isEmpty()) return mask
        val tw = w / cols
        val th = h / rows
        for (r in 0 until rows) for (c in 0 until cols) {
            val cx = (c + 0.5f) * tw
            val cy = (r + 0.5f) * th
            if (rects.any { it.contains(cx, cy) }) mask[r * cols + c] = true
        }
        return mask
    }

    /** A frame that is entirely near-black usually means protected (FLAG_SECURE) or blank content. */
    fun isBlank(grid: IntArray): Boolean = grid.all { it < 6 }
}

/** Picks the area to OCR after a change: the dirty box plus any tracked text it touches. */
object RegionPlanner {
    /** Returns null when the whole frame should be scanned. */
    fun plan(dirty: FRect, trackRects: List<FRect>, w: Float, h: Float, pad: Float = 24f): FRect? {
        var r = dirty.inflate(pad)
        repeat(2) { for (t in trackRects) if (t.intersects(r)) r = r.union(t.inflate(pad / 2f)) }
        r = r.clamp(w, h)
        return if (r.area > 0.55f * w * h) null else r
    }
}

data class ChangeResult(val first: Boolean, val changedTiles: Int, val ratio: Float, val dirty: FRect?, val blank: Boolean)

/**
 * Cheap frame-to-frame change detection on a coarse luma grid. It reads ~8k pixels per frame straight
 * from the capture buffer, so deciding "nothing changed, skip OCR" costs almost nothing.
 */
class ChangeDetector(private val cols: Int = 32, private val rows: Int = 64) {
    private var prev: IntArray? = null
    private var cur = IntArray(cols * rows)

    fun reset() { prev = null }

    fun sample(frame: CapturedFrame) {
        val plane = frame.image.planes[0]
        val buf: ByteBuffer = plane.buffer
        val rowStride = plane.rowStride
        val pixStride = plane.pixelStride
        val w = frame.width
        val h = frame.height
        val limit = buf.limit()
        for (r in 0 until rows) {
            val cy = ((r + 0.5f) * h / rows).toInt()
            for (c in 0 until cols) {
                val cx = ((c + 0.5f) * w / cols).toInt()
                var sum = 0
                var n = 0
                for (dy in -2..2 step 4) for (dx in -2..2 step 4) {
                    val x = (cx + dx).coerceIn(0, w - 1)
                    val y = (cy + dy).coerceIn(0, h - 1)
                    val idx = y * rowStride + x * pixStride
                    if (idx + 2 < limit) {
                        val rr = buf.get(idx).toInt() and 0xFF
                        val gg = buf.get(idx + 1).toInt() and 0xFF
                        val bb = buf.get(idx + 2).toInt() and 0xFF
                        sum += (rr * 77 + gg * 150 + bb * 29) shr 8
                        n++
                    }
                }
                cur[r * cols + c] = if (n == 0) 0 else sum / n
            }
        }
    }

    /** Compares the last [sample] with the previous one, ignoring tiles under our own overlay labels. */
    fun compare(selfRects: List<FRect>, w: Int, h: Int): ChangeResult {
        val p = prev
        val blank = GridMath.isBlank(cur)
        if (p == null) {
            prev = cur.copyOf()
            return ChangeResult(true, cols * rows, 1f, null, blank)
        }
        val mask = GridMath.ignoreMask(selfRects, cols, rows, w.toFloat(), h.toFloat())
        val d = GridMath.diff(p, cur, cols, rows, 10, mask)
        System.arraycopy(cur, 0, p, 0, cur.size)
        val tw = w.toFloat() / cols
        val th = h.toFloat() / rows
        val dirty = if (d.changed == 0) null
        else FRect(d.minC * tw, d.minR * th, (d.maxC + 1) * tw, (d.maxR + 1) * th)
        return ChangeResult(false, d.changed, d.ratio, dirty, blank)
    }
}
