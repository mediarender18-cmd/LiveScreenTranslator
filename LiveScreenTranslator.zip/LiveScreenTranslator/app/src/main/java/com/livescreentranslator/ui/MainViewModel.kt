package com.livescreentranslator.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.livescreentranslator.LstApp
import com.livescreentranslator.data.AppSettings
import com.livescreentranslator.data.TranslationEntity
import com.livescreentranslator.overlay.OverlayHostService
import com.livescreentranslator.service.ForegroundAppDetector
import com.livescreentranslator.service.SessionHub
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class PermState(
    val overlay: Boolean = false,
    val notifications: Boolean = true,
    val accessibility: Boolean = false,
    val usage: Boolean = false,
)

data class AppInfo(val pkg: String, val label: String)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val graph = (app as LstApp).graph

    val settings: StateFlow<AppSettings?> = graph.settingsState
    val session = SessionHub.state
    val downloaded = graph.packs.downloaded
    val busyPacks = graph.packs.busy
    val history: kotlinx.coroutines.flow.Flow<List<TranslationEntity>> = graph.db.dao().recent(200)

    val perms = MutableStateFlow(PermState())
    val apps = MutableStateFlow<List<AppInfo>>(emptyList())
    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    init { viewModelScope.launch { graph.packs.refresh() } }

    fun say(msg: String) { _messages.tryEmit(msg) }

    fun update(f: (AppSettings) -> AppSettings) { viewModelScope.launch { graph.settings.update(f) } }

    fun refreshPerms(ctx: Context) {
        val notif = Build.VERSION.SDK_INT < 33 ||
            ctx.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED
        perms.value = PermState(
            overlay = Settings.canDrawOverlays(ctx),
            notifications = notif,
            accessibility = OverlayHostService.instance != null,
            usage = ForegroundAppDetector.hasUsageAccess(ctx),
        )
    }

    fun downloadPack(lang: String) {
        viewModelScope.launch {
            val wifi = graph.settingsNow().wifiOnlyPacks
            graph.packs.download(lang, wifi).onFailure {
                say(if (wifi) "Download failed. It only runs on Wi-Fi; check your connection or change this in Settings." else "Download failed. Check your connection.")
            }
        }
    }

    fun deletePack(lang: String) { viewModelScope.launch { graph.packs.delete(lang) } }

    fun clearHistory() { viewModelScope.launch { graph.db.dao().clear() } }

    fun hasSecret(id: String) = graph.secrets.has(id)
    fun secretsAvailable() = graph.secrets.available
    fun setSecret(id: String, v: String?) = graph.secrets.set(id, v)

    fun loadApps() {
        if (apps.value.isNotEmpty()) return
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                val pm = ctx.packageManager
                val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                @Suppress("DEPRECATION")
                pm.queryIntentActivities(intent, 0)
                    .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
                    .filter { it.pkg != ctx.packageName }
                    .distinctBy { it.pkg }
                    .sortedBy { it.label.lowercase() }
            }
            apps.value = list
        }
    }
}
