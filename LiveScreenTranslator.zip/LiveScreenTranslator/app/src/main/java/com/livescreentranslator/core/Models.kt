package com.livescreentranslator.core

enum class HAlign { LEFT, CENTER, RIGHT }

/** One paragraph-level piece of recognised text, in capture-frame pixel coordinates. */
data class OcrUnit(
    val text: String,
    val rect: FRect,
    val confidence: Float,
    val lineCount: Int,
    val lineHeight: Float,
    val align: HAlign,
    val vertical: Boolean = false,
)

/** Colours and weight estimated from the pixels around a piece of source text. */
data class LabelStyle(val bg: Int, val fg: Int, val bold: Boolean) {
    companion object {
        val DEFAULT = LabelStyle(0xFF000000.toInt(), 0xFFFFFFFF.toInt(), false)
    }
}

/** A region currently covered by one of our own overlay labels. */
data class SelfLabel(val rect: FRect)
