package com.livescreentranslator.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Compact draggable control: collapsed it is a small translucent handle; one tap expands it to
 * pause/resume, hide-labels, quick settings and stop. It collapses by itself after a few seconds.
 */
@SuppressLint("ViewConstructor")
class FloatingWidgetView(
    ctx: Context,
    private val onExpandChanged: (Boolean) -> Unit,
    private val onPause: () -> Unit,
    private val onHide: () -> Unit,
    private val onSettings: () -> Unit,
    private val onStop: () -> Unit,
    private val onMoved: (dx: Float, dy: Float) -> Unit,
) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val btn = 44f * d
    private val gap = 2f * d
    private val pad = 4f * d
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val handler = Handler(Looper.getMainLooper())

    var expanded = false
        private set
    var paused = false
        set(v) { field = v; invalidate() }
    var labelsHidden = false
        set(v) { field = v; invalidate() }

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE6090A12.toInt() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f * d }
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFE8ECFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 2f * d
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE8ECFF.toInt() }
    private val accent = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF22D3EE.toInt() }
    private val danger = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF5C7A.toInt() }
    private val rect = RectF()
    private val path = Path()

    private val collapseRunnable = Runnable { setExpanded(false) }

    private val buttons get() = 4 // pause, hide, settings, stop

    private fun contentWidth() = if (expanded) pad * 2 + btn * (buttons + 1) + gap * buttons else btn + pad * 2
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(contentWidth().toInt(), (btn + pad * 2).toInt())

    fun setExpanded(v: Boolean) {
        if (v == expanded) return
        expanded = v
        handler.removeCallbacks(collapseRunnable)
        if (v) handler.postDelayed(collapseRunnable, 4500)
        onExpandChanged(v)
        requestLayout()
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        bg.alpha = if (expanded) 230 else 150
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, h / 2, h / 2, bg)
        stroke.shader = LinearGradient(0f, 0f, w, h, 0x884C8DFF.toInt(), 0x8822D3EE.toInt(), Shader.TileMode.CLAMP)
        rect.inset(0.5f * d, 0.5f * d)
        c.drawRoundRect(rect, h / 2, h / 2, stroke)

        // Handle (always first): three short bars.
        val hx = pad + btn / 2
        val cy = h / 2
        for (i in -1..1) c.drawLine(hx - 7f * d, cy + i * 5f * d, hx + 7f * d, cy + i * 5f * d, ink)
        if (!expanded) return

        for (i in 0 until buttons) {
            val cx = pad + btn * (i + 1) + gap * (i + 1) + btn / 2
            when (i) {
                0 -> if (paused) { // play
                    path.reset(); path.moveTo(cx - 5f * d, cy - 8f * d); path.lineTo(cx + 8f * d, cy); path.lineTo(cx - 5f * d, cy + 8f * d); path.close()
                    c.drawPath(path, accent)
                } else {
                    c.drawRoundRect(cx - 7f * d, cy - 8f * d, cx - 2f * d, cy + 8f * d, 1.5f * d, 1.5f * d, fill)
                    c.drawRoundRect(cx + 2f * d, cy - 8f * d, cx + 7f * d, cy + 8f * d, 1.5f * d, 1.5f * d, fill)
                }
                1 -> { // eye / eye-off
                    rect.set(cx - 10f * d, cy - 6f * d, cx + 10f * d, cy + 6f * d)
                    c.drawOval(rect, ink)
                    c.drawCircle(cx, cy, 2.6f * d, if (labelsHidden) accent else fill)
                    if (labelsHidden) c.drawLine(cx - 10f * d, cy + 9f * d, cx + 10f * d, cy - 9f * d, ink)
                }
                2 -> { // sliders
                    for (k in -1..1) {
                        val y = cy + k * 6f * d
                        c.drawLine(cx - 9f * d, y, cx + 9f * d, y, ink)
                        c.drawCircle(cx + (k * 4f * d), y, 2.4f * d, fill)
                    }
                }
                3 -> c.drawRoundRect(cx - 7f * d, cy - 7f * d, cx + 7f * d, cy + 7f * d, 2.5f * d, 2.5f * d, danger)
            }
        }
    }

    private var downX = 0f; private var downY = 0f
    private var lastX = 0f; private var lastY = 0f
    private var dragging = false

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; lastX = downX; lastY = downY; dragging = false
                handler.removeCallbacks(collapseRunnable)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && hypot(e.rawX - downX, e.rawY - downY) > slop) dragging = true
                if (dragging) { onMoved(e.rawX - lastX, e.rawY - lastY); lastX = e.rawX; lastY = e.rawY }
            }
            MotionEvent.ACTION_UP -> {
                if (!dragging) tap(e.x)
                if (expanded) { handler.removeCallbacks(collapseRunnable); handler.postDelayed(collapseRunnable, 4500) }
            }
            MotionEvent.ACTION_CANCEL -> if (expanded) handler.postDelayed(collapseRunnable, 4500)
        }
        return true
    }

    private fun tap(x: Float) {
        if (!expanded) { setExpanded(true); return }
        val idx = ((x - pad) / (btn + gap)).toInt()
        when (idx) {
            0 -> setExpanded(false)
            1 -> onPause()
            2 -> onHide()
            3 -> { onSettings(); setExpanded(false) }
            4 -> onStop()
        }
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(collapseRunnable)
        super.onDetachedFromWindow()
    }
}

class FloatingWidget(
    private val ctx: Context,
    private val host: OverlayHost,
    private val callbacks: Callbacks,
) {
    interface Callbacks { fun onPause(); fun onHide(); fun onSettings(); fun onStop() }

    private val prefs = ctx.getSharedPreferences("widget", Context.MODE_PRIVATE)
    private var view: FloatingWidgetView? = null
    private var wm: WindowManager? = null
    private var params: WindowManager.LayoutParams? = null

    /** Main thread only. */
    fun show() {
        if (view != null) return
        // The widget needs touches, so it always uses a normal application overlay when permitted.
        val t = host.target() ?: return
        val w = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val type = if (android.provider.Settings.canDrawOverlays(ctx)) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else t.type
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = prefs.getInt("x", 16)
        p.y = prefs.getInt("y", 220)
        val mgr = if (type == WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY) w else t.wm
        val v = FloatingWidgetView(
            ctx,
            onExpandChanged = { expanded -> if (expanded) keepOnScreen() },
            onPause = callbacks::onPause, onHide = callbacks::onHide,
            onSettings = callbacks::onSettings, onStop = callbacks::onStop,
            onMoved = { dx, dy ->
                p.x += dx.toInt(); p.y += dy.toInt()
                runCatching { mgr.updateViewLayout(view, p) }
                prefs.edit().putInt("x", p.x).putInt("y", p.y).apply()
            },
        )
        try { mgr.addView(v, p) } catch (e: Exception) { return }
        view = v; wm = mgr; params = p
    }

    private fun keepOnScreen() {
        val p = params ?: return
        val v = view ?: return
        val screenW = ctx.resources.displayMetrics.widthPixels
        v.post {
            val over = p.x + v.measuredWidth - screenW
            if (over > 0) { p.x = (p.x - over - 8).coerceAtLeast(0); runCatching { wm?.updateViewLayout(v, p) } }
        }
    }

    fun setState(paused: Boolean, labelsHidden: Boolean) {
        view?.paused = paused
        view?.labelsHidden = labelsHidden
    }

    fun hide() {
        view?.let { runCatching { wm?.removeView(it) } }
        view = null; wm = null; params = null
    }
}
