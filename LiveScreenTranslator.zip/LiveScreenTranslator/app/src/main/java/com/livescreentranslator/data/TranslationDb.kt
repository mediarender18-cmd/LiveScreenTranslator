package com.livescreentranslator.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import com.livescreentranslator.translate.TranslationStore
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "translations", indices = [Index(value = ["src", "tgt", "srcText"], unique = true)])
data class TranslationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val src: String,
    val tgt: String,
    val srcText: String,
    val outText: String,
    val engine: String,
    val createdAt: Long,
)

@Dao
interface TranslationDao {
    @Query("SELECT outText FROM translations WHERE src = :src AND tgt = :tgt AND srcText = :text LIMIT 1")
    suspend fun find(src: String, tgt: String, text: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(e: TranslationEntity)

    @Query("SELECT * FROM translations ORDER BY createdAt DESC LIMIT :limit")
    fun recent(limit: Int): Flow<List<TranslationEntity>>

    @Query("DELETE FROM translations")
    suspend fun clear()

    @Query("DELETE FROM translations WHERE id NOT IN (SELECT id FROM translations ORDER BY createdAt DESC LIMIT :keep)")
    suspend fun trim(keep: Int)
}

@Database(entities = [TranslationEntity::class], version = 1, exportSchema = false)
abstract class TranslationDb : RoomDatabase() {
    abstract fun dao(): TranslationDao
}

/** Persistent translation memory + history. Writes are skipped entirely when the user disabled history. */
class RoomTranslationStore(
    private val dao: TranslationDao,
    private val enabled: () -> Boolean,
) : TranslationStore {
    private var writes = 0

    override suspend fun find(src: String, tgt: String, text: String): String? =
        if (enabled()) dao.find(src, tgt, text) else null

    override suspend fun save(src: String, tgt: String, text: String, out: String, engine: String) {
        if (!enabled()) return
        dao.upsert(TranslationEntity(src = src, tgt = tgt, srcText = text, outText = out, engine = engine, createdAt = System.currentTimeMillis()))
        if (++writes % 100 == 0) dao.trim(3000)
    }
}
