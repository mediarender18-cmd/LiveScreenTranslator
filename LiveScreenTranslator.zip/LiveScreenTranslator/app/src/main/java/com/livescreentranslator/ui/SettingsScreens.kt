package com.livescreentranslator.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.livescreentranslator.data.AppSettings
import com.livescreentranslator.data.ConcealMode
import com.livescreentranslator.data.EngineChoice
import com.livescreentranslator.data.Languages
import com.livescreentranslator.data.QualityPref
import com.livescreentranslator.data.ThemeChoice
import com.livescreentranslator.ui.theme.Cyan
import com.livescreentranslator.ui.theme.Danger
import java.text.DateFormat
import java.util.Date

@Composable
private fun ScreenColumn(pad: PaddingValues, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) { content(); Spacer(Modifier.height(24.dp)) }
}

@Composable
private fun Header(title: String, onBack: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
        Text(title, style = MaterialTheme.typography.headlineMedium)
    }
}

@Composable
private fun Divider() = HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

@Composable
fun SettingsScreen(
    vm: MainViewModel, actions: HostActions, s: AppSettings, downloaded: Set<String>, pad: PaddingValues,
    onPick: (isSource: Boolean) -> Unit, onSub: (Sub) -> Unit,
) {
    val perms by vm.perms.collectAsState()
    ScreenColumn(pad) {
        Header("Settings")

        SectionTitle("Translation")
        GlassCard {
            SettingRow("Source language", Languages.name(s.source), { onPick(true) })
            Divider()
            SettingRow("Target language", Languages.name(s.target), { onPick(false) })
            Divider()
            Text("Engine", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp, bottom = 8.dp))
            ChipRow(
                listOf(EngineChoice.AUTO to "Auto", EngineChoice.OFFLINE to "On-device", EngineChoice.GOOGLE to "Google Cloud", EngineChoice.LIBRE to "LibreTranslate"),
                s.engine,
            ) { e -> vm.update { it.copy(engine = e) } }
            Text(engineBlurb(s), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(8.dp))
            Divider()
            SettingRow("Offline language packs", "${downloaded.size} downloaded", { onSub(Sub.PACKS) })
            Divider()
            SettingRow("Online providers", if (s.onlineConsent) "Allowed" else "Off", { onSub(Sub.ONLINE) })
            Divider()
            Text("Speed vs quality", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp, bottom = 8.dp))
            ChipRow(listOf(QualityPref.LATENCY to "Fastest", QualityPref.BALANCED to "Balanced", QualityPref.QUALITY to "Best quality"), s.quality) { q -> vm.update { it.copy(quality = q) } }
            Text("Fastest samples more often at lower resolution. Best quality reads small fonts better and waits longer for partial text to settle.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
        }

        SectionTitle("Overlay")
        GlassCard {
            Text("Hide original text with", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 8.dp))
            ChipRow(listOf(ConcealMode.ADAPTIVE to "Matching colour", ConcealMode.BLACK to "Black", ConcealMode.BORDERLESS to "Borderless"), s.conceal) { c -> vm.update { it.copy(conceal = c) } }
            if (s.conceal == ConcealMode.BLACK) {
                SliderRow("Background opacity", s.bgOpacity, 0.2f..1f, { "${(it * 100).toInt()}%" }) { v -> vm.update { it.copy(bgOpacity = v) } }
            }
            SliderRow("Text size", s.textScale, 0.7f..1.5f, { "${(it * 100).toInt()}%" }) { v -> vm.update { it.copy(textScale = v) } }
            Divider()
            SwitchRow(
                "Strong concealment", "Fully opaque labels. On Android 12+ taps can't pass through them unless the optional overlay helper below is on.",
                s.strongConceal,
            ) { v -> vm.update { it.copy(strongConceal = v) } }
        }

        SectionTitle("Animation")
        GlassCard {
            SliderRow("Animation speed", s.animSpeed, 0.5f..2f, { "%.1f×".format(it) }) { v -> vm.update { it.copy(animSpeed = v) } }
            SwitchRow("Typing animation", "Reveals translated text progressively.", s.typing) { v -> vm.update { it.copy(typing = v) } }
        }

        SectionTitle("Battery and apps")
        GlassCard {
            SwitchRow("Battery saver", "Samples less often and at lower resolution. Also applied automatically at 20% battery, in Android battery saver, or when the device runs hot.", s.batterySaver) { v -> vm.update { it.copy(batterySaver = v) } }
            Divider()
            SettingRow("Pause for specific apps", if (s.excludedApps.isEmpty()) "None" else "${s.excludedApps.size} apps", { onSub(Sub.APPS) })
        }

        SectionTitle("Privacy")
        GlassCard {
            SwitchRow("Keep translation history", "Saves translated text (never screenshots) on this device and reuses it for repeated labels. Turn off to keep nothing.", s.keepHistory) { v -> vm.update { it.copy(keepHistory = v) } }
            Divider()
            SwitchRow("Download packs on Wi-Fi only", null, s.wifiOnlyPacks) { v -> vm.update { it.copy(wifiOnlyPacks = v) } }
            Divider()
            TextButton({ vm.clearHistory() }) { Text("Clear history now", color = Danger) }
            Text("Screen frames are analysed in memory and discarded. No screenshots are saved or uploaded. When an online engine is used, only extracted text is sent to that provider.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SectionTitle("Permissions")
        GlassCard {
            PermRow("Display over other apps", "Required", perms.overlay, actions::requestOverlay)
            Divider()
            PermRow("Notifications", "Shows Pause and Stop while running", perms.notifications, actions::requestNotifications)
            Divider()
            PermRow("Trusted overlay helper (accessibility)", "Optional. Lets taps pass through labels at full opacity. It cannot read your screen.", perms.accessibility, actions::openAccessibility)
            Divider()
            PermRow("Usage access", "Optional. Needed only for per-app pause.", perms.usage, actions::openUsageAccess)
        }

        SectionTitle("Appearance")
        GlassCard {
            ChipRow(listOf(ThemeChoice.DARK to "Dark", ThemeChoice.LIGHT to "Light", ThemeChoice.SYSTEM to "System"), s.theme) { t -> vm.update { it.copy(theme = t) } }
        }
    }
}

@Composable
private fun PermRow(title: String, sub: String, granted: Boolean, onClick: () -> Unit) {
    SettingRow(title, sub, null) {
        if (granted) Text("On", color = Cyan, style = MaterialTheme.typography.labelLarge)
        else TextButton(onClick) { Text("Set up") }
    }
}

private fun engineBlurb(s: AppSettings): String = when (s.engine) {
    EngineChoice.OFFLINE -> "Everything stays on this device. Works offline once packs are downloaded."
    EngineChoice.AUTO -> if (s.onlineConsent) "Uses on-device translation first and falls back to an online provider you configured. Extracted text may be sent to it." else "On-device translation. Enable online providers to add a fallback."
    EngineChoice.GOOGLE -> "Sends extracted text (not images) to Google Cloud Translation. Falls back to on-device if it fails."
    EngineChoice.LIBRE -> "Sends extracted text (not images) to the LibreTranslate server you configure. Falls back to on-device if it fails."
}

// --------------------------------------------------------------------------- packs

@Composable
fun PacksScreen(vm: MainViewModel, s: AppSettings, pad: PaddingValues, onBack: () -> Unit) {
    val downloaded by vm.downloaded.collectAsState()
    val busy by vm.busyPacks.collectAsState()
    Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 20.dp, vertical = 16.dp)) {
        Header("Offline language packs", onBack)
        Text("Each pack is roughly 30 MB. English is built in. A pair works offline only when both languages are installed. Languages not listed here can't be translated offline.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        SwitchRow("Wi-Fi only", null, s.wifiOnlyPacks) { v -> vm.update { it.copy(wifiOnlyPacks = v) } }
        LazyColumn {
            items(Languages.all.filter { it.code != "en" }, key = { it.code }) { l ->
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(l.name, style = MaterialTheme.typography.titleMedium)
                        Text(l.native, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    when {
                        l.code in busy -> CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                        l.code in downloaded -> TextButton({ vm.deletePack(l.code) }) { Text("Delete", color = Danger) }
                        else -> TextButton({ vm.downloadPack(l.code) }) { Text("Download") }
                    }
                }
                Divider()
            }
        }
    }
}

// --------------------------------------------------------------------------- online providers

@Composable
fun OnlineScreen(vm: MainViewModel, s: AppSettings, pad: PaddingValues, onBack: () -> Unit) {
    var googleUrl by remember(s.googleEndpoint) { mutableStateOf(s.googleEndpoint) }
    var libreUrl by remember(s.libreEndpoint) { mutableStateOf(s.libreEndpoint) }
    var googleKey by remember { mutableStateOf("") }
    var libreKey by remember { mutableStateOf("") }
    var googleSaved by remember { mutableStateOf(vm.hasSecret("google")) }
    var libreSaved by remember { mutableStateOf(vm.hasSecret("libre")) }

    ScreenColumn(pad) {
        Header("Online providers", onBack)
        GlassCard {
            SwitchRow(
                "Allow sending text to online providers", null, s.onlineConsent,
            ) { v -> vm.update { it.copy(onlineConsent = v) } }
            Text(
                "When on, the text recognised on your screen (never screenshots) is sent over HTTPS to the provider you pick below, and their privacy terms apply. It may include anything visible: chat messages, names, addresses. Leave this off to keep everything on-device.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (!vm.secretsAvailable()) {
            Text("Secure key storage isn't available on this device, so API keys can't be saved. Use a proxy URL that holds the key instead.", color = Danger, style = MaterialTheme.typography.bodySmall)
        }

        SectionTitle("Google Cloud Translation")
        GlassCard {
            OutlinedTextField(googleUrl, { googleUrl = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Proxy URL (optional, https)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(googleKey, { googleKey = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(if (googleSaved) "Key saved. Type to replace" else "API key") }, visualTransformation = PasswordVisualTransformation())
            Row {
                TextButton({
                    vm.update { it.copy(googleEndpoint = googleUrl.trim()) }
                    if (googleKey.isNotBlank()) { vm.setSecret("google", googleKey); googleKey = ""; googleSaved = true }
                    vm.say("Saved")
                }) { Text("Save") }
                if (googleSaved) TextButton({ vm.setSecret("google", null); googleSaved = false }) { Text("Remove key", color = Danger) }
            }
            Text("Keys are stored encrypted on this device and are never part of the app. For anything beyond personal use, point the proxy URL at your own backend so the real key never reaches the phone.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        SectionTitle("LibreTranslate")
        GlassCard {
            OutlinedTextField(libreUrl, { libreUrl = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Server URL (https)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri))
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(libreKey, { libreKey = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(if (libreSaved) "Key saved. Type to replace" else "API key (if the server needs one)") }, visualTransformation = PasswordVisualTransformation())
            Row {
                TextButton({
                    vm.update { it.copy(libreEndpoint = libreUrl.trim()) }
                    if (libreKey.isNotBlank()) { vm.setSecret("libre", libreKey); libreKey = ""; libreSaved = true }
                    vm.say("Saved")
                }) { Text("Save") }
                if (libreSaved) TextButton({ vm.setSecret("libre", null); libreSaved = false }) { Text("Remove key", color = Danger) }
            }
        }
    }
}

// --------------------------------------------------------------------------- per-app exclusions

@Composable
fun AppsScreen(vm: MainViewModel, actions: HostActions, s: AppSettings, pad: PaddingValues, onBack: () -> Unit) {
    val apps by vm.apps.collectAsState()
    val perms by vm.perms.collectAsState()
    LaunchedEffect(Unit) { vm.loadApps() }
    Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 20.dp, vertical = 16.dp)) {
        Header("Pause for specific apps", onBack)
        Text("Checked apps are left alone: no capture analysis and no overlay while they are in front.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (!perms.usage) {
            Spacer(Modifier.height(8.dp))
            PermCard("Usage access", "Android needs this to tell which app is in front. It's used for nothing else.", false, "Grant") { actions.openUsageAccess() }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(apps, key = { it.pkg }) { a ->
                val on = a.pkg in s.excludedApps
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.label, style = MaterialTheme.typography.titleMedium)
                        Text(a.pkg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Checkbox(on, { c -> vm.update { it.copy(excludedApps = if (c) it.excludedApps + a.pkg else it.excludedApps - a.pkg) } })
                }
            }
        }
    }
}

// --------------------------------------------------------------------------- history

@Composable
fun HistoryScreen(vm: MainViewModel, s: AppSettings, pad: PaddingValues) {
    val items by vm.history.collectAsState(initial = emptyList())
    val fmt = remember { DateFormat.getTimeInstance(DateFormat.SHORT) }
    Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 20.dp, vertical = 16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Header("History") }
            if (items.isNotEmpty()) TextButton({ vm.clearHistory() }) { Text("Clear", color = Danger) }
        }
        if (!s.keepHistory) {
            Text("History is turned off. Nothing is being saved. You can turn it on in Settings → Privacy.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else if (items.isEmpty()) {
            Text("Translations will appear here as they happen.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LazyColumn {
            items(items, key = { it.id }) { e ->
                Column(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                    Text(e.srcText, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3)
                    Text(e.outText, style = MaterialTheme.typography.titleMedium, maxLines = 4)
                    Text("${e.src} → ${e.tgt} · ${e.engine} · ${fmt.format(Date(e.createdAt))}", style = MaterialTheme.typography.labelSmall, color = Cyan)
                }
                Divider()
            }
        }
    }
}
