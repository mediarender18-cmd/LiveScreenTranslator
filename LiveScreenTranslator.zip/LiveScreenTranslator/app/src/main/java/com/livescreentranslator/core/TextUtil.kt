package com.livescreentranslator.core

import kotlin.math.max
import kotlin.math.min

object TextUtil {
    private val WS = Regex("\\s+")
    private val URL = Regex("(https?://|www\\.)\\S+|\\S+@\\S+\\.\\S+")

    fun normalize(s: String): String = s.trim().replace(WS, " ")

    fun digits(s: String): String = s.filter { it.isDigit() }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    /** 1.0 = identical, 0.0 = nothing in common. Long strings are compared on their first 300 chars. */
    fun similarity(a: String, b: String): Float {
        if (a == b) return 1f
        val x = a.take(300)
        val y = b.take(300)
        val m = max(x.length, y.length)
        if (m == 0) return 1f
        return 1f - levenshtein(x, y).toFloat() / m
    }

    /** True when [new] looks like [old] with more text typed after it (tolerating OCR noise). */
    fun isGrowth(old: String, new: String): Boolean {
        if (old.isEmpty() || new.length <= old.length) return false
        return similarity(old, new.substring(0, old.length)) >= 0.85f
    }

    fun isIdeographic(ch: Char): Boolean {
        val b = Character.UnicodeBlock.of(ch)
        return b == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS ||
            b == Character.UnicodeBlock.HIRAGANA ||
            b == Character.UnicodeBlock.KATAKANA ||
            b == Character.UnicodeBlock.HANGUL_SYLLABLES ||
            b == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
    }

    fun hasIdeograph(s: String): Boolean = s.any { isIdeographic(it) }

    /** Filters out numbers, URLs, lone symbols and other text that must not be translated. */
    fun shouldTranslate(s: String): Boolean {
        val t = s.trim()
        if (t.isEmpty() || URL.containsMatchIn(t)) return false
        var letters = 0
        var digits = 0
        var ideo = false
        for (ch in t) {
            if (ch.isLetter()) {
                letters++
                if (isIdeographic(ch)) ideo = true
            } else if (ch.isDigit()) digits++
        }
        if (ideo) return true
        return letters >= 2 && letters >= digits
    }
}
