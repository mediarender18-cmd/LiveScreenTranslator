package com.livescreentranslator.service

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import com.livescreentranslator.AppGraph
import com.livescreentranslator.capture.CaptureEngine
import com.livescreentranslator.capture.CapturedFrame
import com.livescreentranslator.capture.ChangeDetector
import com.livescreentranslator.capture.FrameUtil
import com.livescreentranslator.capture.RegionPlanner
import com.livescreentranslator.core.CoordinateMapper
import com.livescreentranslator.core.FRect
import com.livescreentranslator.core.HAlign
import com.livescreentranslator.core.LabelStyle
import com.livescreentranslator.core.OcrUnit
import com.livescreentranslator.core.SelfLabel
import com.livescreentranslator.data.AppSettings
import com.livescreentranslator.data.ConcealMode
import com.livescreentranslator.data.Languages
import com.livescreentranslator.data.QualityPref
import com.livescreentranslator.ocr.MlKitOcrEngine
import com.livescreentranslator.ocr.OcrEngine
import com.livescreentranslator.ocr.OcrPostProcessor
import com.livescreentranslator.ocr.OcrScript
import com.livescreentranslator.overlay.LabelSpec
import com.livescreentranslator.overlay.OverlayConfig
import com.livescreentranslator.overlay.OverlayController
import com.livescreentranslator.overlay.OverlayHost
import com.livescreentranslator.overlay.StyleSampler
import com.livescreentranslator.track.ChangeKind
import com.livescreentranslator.track.TextTracker
import com.livescreentranslator.track.Track
import com.livescreentranslator.track.TrackState
import com.livescreentranslator.track.TrackerDelta
import com.livescreentranslator.translate.LangPair
import com.livescreentranslator.translate.TranslationCache
import com.livescreentranslator.translate.TranslationCoordinator
import com.livescreentranslator.translate.TranslationRequest
import com.livescreentranslator.translate.TranslationResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * capture → change detection → OCR → text tracking → translation → overlay.
 *
 * All mutable pipeline state lives on one single-threaded dispatcher, so no locking is needed. The only
 * work that leaves it is OCR (ML Kit's own threads) and translation (the coordinator's scope).
 *
 * Why "peeks" exist: MediaProjection captures our own overlay too, and Android has no public way to exclude
 * it. So text hidden under one of our labels cannot be re-read by normal scans. Instead, labels are verified
 * by hiding them for a few frames, grabbing a frame, then showing them again. Verification is rare for static
 * text (the interval backs off exponentially) and fast for text that is being typed.
 */
class Pipeline(
    private val app: Application,
    private val graph: AppGraph,
    private val capture: CaptureEngine,
    private val overlay: OverlayController,
    private val host: OverlayHost,
    private val onFatal: (String) -> Unit,
) {
    private val dispatcher = Dispatchers.Default.limitedParallelism(1)
    private val scope = CoroutineScope(SupervisorJob() + dispatcher)
    private val workScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Volatile private var cfg: AppSettings = graph.settingsNow()
    private val ocr: OcrEngine = MlKitOcrEngine()
    private val post = OcrPostProcessor()
    private val tracker = TextTracker()
    private val detector = ChangeDetector()
    private val fgApp = ForegroundAppDetector(app)
    private val coordinator = TranslationCoordinator(
        scope = workScope,
        providers = { graph.providersFor(cfg) },
        pair = { LangPair(cfg.source, cfg.target) },
        detect = { graph.detector.detect(it) },
        cache = TranslationCache(graph.newStore()),
    )

    @Volatile var paused = false
        private set
    @Volatile var labelsHidden = false
        private set

    private var mapper: CoordinateMapper? = null
    private var lastW = 0
    private var lastH = 0
    private var held: CapturedFrame? = null
    private var pendingDirty: FRect? = null
    private var pendingFull = true
    private var lastChangeAt = 0L
    private var motion = false
    private var sceneCut = false
    private var lastOcrEnd = 0L
    private var avgOcrMs = 120f
    private var excluded = false
    private var ocrBlocked = false
    private var cfgKey: String? = null
    private var blankSince = 0L
    private var lastFgCheck = 0L
    private var lastPermCheck = 0L
    private var lastPolicyCheck = -10_000L
    private var eco = false
    private var hot = false
    private var detected = 0
    private var translated = 0
    private val dirty = LinkedHashSet<Long>()
    private val gone = LinkedHashSet<Long>()

    // ------------------------------------------------------------------ lifecycle

    fun start() {
        coordinator.start()
        scope.launch { graph.settingsState.filterNotNull().collect { onSettings(it) } }
        scope.launch { for (r in coordinator.results) applyResult(r) }
        scope.launch { coordinator.status.collect { st -> SessionHub.update { it.copy(engineStatus = st.label) } } }
        scope.launch { loop() }
    }

    fun stop() {
        scope.cancel()
        workScope.cancel()
        coordinator.stop()
        held?.close(); held = null
        runCatching { ocr.close() }
        overlay.clear()
    }

    fun setPaused(p: Boolean) {
        if (p == paused) return
        paused = p   // flipped synchronously so callers can read the new state straight away
        scope.launch {
            if (p) {
                capture.pause()
                overlay.setHidden(true)
                clearAll()
                SessionHub.update { it.copy(phase = Phase.PAUSED, ocrStatus = "Paused") }
            } else {
                capture.resume()
                overlay.setHidden(labelsHidden || excluded)
                pendingFull = true
                SessionHub.update { it.copy(phase = Phase.RUNNING, ocrStatus = "Scanning") }
            }
        }
    }

    fun toggleLabels() {
        labelsHidden = !labelsHidden
        scope.launch {
            overlay.setHidden(labelsHidden || excluded || paused)
            // With labels hidden the originals are visible again, so ordinary scans can read them.
            for (t in tracker.tracks) t.covered = hasOverlay(t)
            SessionHub.update { it.copy(labelsHidden = labelsHidden) }
        }
    }

    // ------------------------------------------------------------------ settings

    private suspend fun onSettings(s: AppSettings) {
        cfg = s
        val key = "${s.source}|${s.target}|${s.engine}|${s.onlineConsent}"
        if (cfgKey != null && key != cfgKey) resetTranslations()
        cfgKey = key
        overlay.setConfig(OverlayConfig(s.animSpeed, s.typing, s.textScale))
        overlay.setStrongConceal(s.strongConceal)
        capture.setLongSide(longSideFor(s))
        val lang = Languages.byCode[s.source]
        ocrBlocked = lang != null && lang.ocr == null
        if (ocrBlocked) {
            SessionHub.update { it.copy(ocrStatus = "On-device OCR can't read ${lang!!.name} text. Pick another source language or Auto.") }
        }
        for (t in tracker.tracks) dirty += t.id   // restyle after concealment / target changes
        flush()
    }

    private suspend fun resetTranslations() {
        coordinator.reset()
        for (t in tracker.tracks) {
            t.translation = null; t.translationVersion = -1; t.errorCount = 0; t.errorAt = 0L
            t.skip = false; t.provisional = false; t.covered = false
            dirty += t.id
            requestTranslation(t, false)
        }
        flush()
    }

    private fun longSideFor(s: AppSettings): Int =
        if (s.batterySaver || eco) 1280 else when (s.quality) {
            QualityPref.LATENCY -> 1280
            QualityPref.BALANCED -> 1600
            QualityPref.QUALITY -> 2000
        }

    // ------------------------------------------------------------------ main loop

    private suspend fun loop() {
        while (currentCoroutineContext().isActive) {
            val now = SystemClock.elapsedRealtime()
            try {
                housekeeping(now)
                if (paused || excluded || ocrBlocked) { delay(250); continue }
                val interval = scanInterval()
                val f = capture.acquire()
                if (f != null) ingest(f, now)
                val wantScan = held != null && (pendingFull || pendingDirty != null)
                val gap = if (motion) max(interval * 2, 450L) else interval
                if (wantScan && now - lastOcrEnd >= gap) { runScan(now); continue }
                val due = duePeeks(now)
                if (due.isNotEmpty() && now - lastOcrEnd >= interval / 2) { runPeek(due, now); continue }
                if (now - lastOcrEnd > 1500) SessionHub.update { it.copy(ocrStatus = "Watching · screen is static") }
                delay(if (wantScan) 15L else if (cfg.batterySaver || eco) 90L else 35L)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                SessionHub.update { it.copy(ocrStatus = "Recovering from an error: ${e.message ?: e.javaClass.simpleName}") }
                delay(500)
            }
        }
    }

    private fun scanInterval(): Long {
        var base = when (cfg.quality) {
            QualityPref.LATENCY -> 90f
            QualityPref.BALANCED -> 150f
            QualityPref.QUALITY -> 230f
        }
        if (eco) base *= 2.2f
        if (hot) base *= 1.8f
        base = max(base, avgOcrMs * 1.25f)
        if (tracker.tracks.any { it.state == TrackState.TYPING }) base = max(70f, avgOcrMs * 1.1f)
        return base.toLong()
    }

    private fun ingest(f: CapturedFrame, now: Long) {
        if (f.width != lastW || f.height != lastH) onSizeChange(f.width, f.height)
        detector.sample(f)
        val ch = detector.compare(tracker.tracks.filter { it.covered }.map { it.rect.inflate(2f) }, f.width, f.height)
        if (ch.blank) {
            if (blankSince == 0L) blankSince = now
            else if (now - blankSince > 2000) {
                SessionHub.update { it.copy(ocrStatus = "Blank or protected screen. Android doesn't allow capturing this content.") }
            }
        } else blankSince = 0L
        if (ch.first || ch.changedTiles >= 3) {
            held?.close(); held = f
            if (ch.first) pendingFull = true else ch.dirty?.let { d -> pendingDirty = pendingDirty?.union(d) ?: d }
            lastChangeAt = now
            motion = ch.ratio > 0.35f
            if (!ch.first && ch.ratio > 0.6f) sceneCut = true
        } else f.close()
    }

    private fun onSizeChange(w: Int, h: Int) {
        lastW = w; lastH = h
        mapper = CoordinateMapper(w, h, max(1, capture.screenW), max(1, capture.screenH))
        clearAll()
    }

    private fun clearAll() {
        tracker.clear()
        coordinator.reset()
        overlay.clear()
        detector.reset()
        held?.close(); held = null
        pendingDirty = null
        pendingFull = true
        dirty.clear(); gone.clear()
    }

    // ------------------------------------------------------------------ scanning

    private suspend fun runScan(now: Long) {
        val f = held ?: return
        held = null
        val full = pendingFull
        val box = pendingDirty
        pendingFull = false
        pendingDirty = null
        val region = if (full || box == null) null
        else RegionPlanner.plan(box, tracker.tracks.filter { !it.covered }.map { it.rect }, f.width.toFloat(), f.height.toFloat())
        val bmp = FrameUtil.toBitmap(f.image)
        f.close()
        try { scan(bmp, region) } finally { bmp.recycle() }
    }

    private suspend fun scan(bmp: Bitmap, region: FRect?) {
        val w = bmp.width
        val h = bmp.height
        val t0 = SystemClock.elapsedRealtime()
        val script = Languages.byCode[cfg.source]?.ocr ?: OcrScript.LATIN
        val units: List<OcrUnit> = if (region == null) {
            ocr.recognize(bmp, script, 0f, 0f, w.toFloat())
        } else {
            val x = region.left.toInt().coerceIn(0, w - 1)
            val y = region.top.toInt().coerceIn(0, h - 1)
            val cw = (region.right.toInt() - x).coerceIn(1, w - x)
            val ch = (region.bottom.toInt() - y).coerceIn(1, h - y)
            val crop = Bitmap.createBitmap(bmp, x, y, cw, ch)
            try { ocr.recognize(crop, script, x.toFloat(), y.toFloat(), w.toFloat()) } finally { crop.recycle() }
        }
        val ms = SystemClock.elapsedRealtime() - t0
        avgOcrMs = avgOcrMs * 0.7f + ms * 0.3f

        val now = SystemClock.elapsedRealtime()
        val kept = post.process(units, w, h, tracker.tracks.filter { it.covered }.map { SelfLabel(it.rect) })
        val scanRect = region ?: FRect(0f, 0f, w.toFloat(), h.toFloat())
        val delta = tracker.update(kept, now, scanRect, w.toFloat(), h.toFloat(), sceneCut)
        sceneCut = false
        onDelta(delta, bmp)
        lastOcrEnd = SystemClock.elapsedRealtime()
        SessionHub.update { it.copy(ocrStatus = "Scanning · $ms ms", lastOcrMs = ms.toInt()) }
    }

    // ------------------------------------------------------------------ verification peeks

    private fun duePeeks(now: Long): List<Track> {
        val ecoFactor = if (eco) 2 else 1
        return tracker.tracks.filter { t ->
            if (!t.covered) return@filter false
            val age = now - t.verifiedAt
            val interval = if (t.state == TrackState.TYPING) min(t.peekIntervalMs, 350L) else t.peekIntervalMs
            val recheck = (if (t.text.length > 40 || t.lineCount >= 2) 2500L else 12_000L) * ecoFactor
            age >= interval && (t.state == TrackState.TYPING || lastChangeAt > t.verifiedAt || age >= recheck)
        }.sortedBy { it.verifiedAt }.take(3)
    }

    /**
     * Hides the due labels for a moment, grabs a clean frame, restores the labels immediately, and only then
     * runs OCR on the area they cover. Timing constants are tuned heuristics (display pipeline latency varies
     * between devices); see the README.
     */
    private suspend fun runPeek(due: List<Track>, now: Long) {
        val ids = due.map { it.id }.toSet()
        due.forEach { it.covered = false }
        overlay.setPeekHidden(ids, true)
        val t0 = System.nanoTime()
        val f = awaitFrameAfter(t0)
        overlay.setPeekHidden(ids, false)
        if (f == null) {
            due.forEach { it.covered = hasOverlay(it); it.verifiedAt = now }
            return
        }
        val w = f.width.toFloat()
        val h = f.height.toFloat()
        val region = FRect.unionAll(due.map { it.rect })!!.inflate(14f).clamp(w, h)
        val bmp = FrameUtil.toBitmap(f.image)
        f.close()
        try { scan(bmp, region) } finally { bmp.recycle() }
        for (t in due) if (tracker.get(t.id) != null) t.covered = hasOverlay(t)
    }

    private suspend fun awaitFrameAfter(t0: Long): CapturedFrame? {
        delay(PEEK_SETTLE_MS)
        val deadline = SystemClock.elapsedRealtime() + PEEK_TIMEOUT_MS
        while (SystemClock.elapsedRealtime() < deadline) {
            val f = capture.acquire()
            if (f != null) {
                val ts = f.timestampNs
                val nano = System.nanoTime()
                // If the image clock isn't comparable with ours, fall back to wall-clock waiting.
                val ok = if (abs(ts - nano) > 2_000_000_000L) nano - t0 >= 60_000_000L else ts >= t0 + PEEK_MIN_AGE_NS
                if (ok) return f
                f.close()
            }
            delay(12)
        }
        return null
    }

    // ------------------------------------------------------------------ tracker deltas → translation → overlay

    private suspend fun onDelta(delta: TrackerDelta, bmp: Bitmap) {
        for (t in delta.removed) { gone += t.id; dirty.remove(t.id); coordinator.cancel(t.id) }
        for (t in delta.added) {
            detected++
            t.style = StyleSampler.sample(bmp, t.rect)
            requestTranslation(t, false)
            dirty += t.id
        }
        for ((t, kind) in delta.changed) {
            when (kind) {
                ChangeKind.MOVED -> dirty += t.id
                ChangeKind.GROWING -> {
                    t.style = StyleSampler.sample(bmp, t.rect)
                    requestTranslation(t, true)   // keep the old translation visible while the new one is pending
                    dirty += t.id
                }
                ChangeKind.REPLACED -> {
                    // Never leave a translation of the *previous* text over new content.
                    t.translation = null; t.provisional = false; t.errorCount = 0
                    t.style = StyleSampler.sample(bmp, t.rect)
                    requestTranslation(t, false)
                    dirty += t.id
                }
                ChangeKind.NONE -> {}
            }
        }
        SessionHub.update { it.copy(detected = detected) }
        flush()
    }

    private suspend fun requestTranslation(t: Track, provisional: Boolean) {
        val priority = when {
            t.text.length <= 24 -> 3
            provisional -> 2
            else -> 1
        }
        val delayMs = if (!provisional) 0L else when (cfg.quality) {
            QualityPref.LATENCY -> 80L
            QualityPref.BALANCED -> 140L
            QualityPref.QUALITY -> 260L
        }
        coordinator.submit(TranslationRequest(t.id, t.textVersion, t.text, provisional, priority, delayMs))
    }

    private fun applyResult(r: TranslationResult) {
        val t = tracker.get(r.trackId) ?: return
        if (r.version > t.textVersion || r.version < t.translationVersion) return
        when {
            r.sameLanguage -> t.skip = true
            r.error != null -> { t.errorCount++; t.errorAt = SystemClock.elapsedRealtime() }
            r.translated != null -> {
                t.translation = r.translated
                t.translationVersion = r.version
                t.srcLang = r.srcLang ?: t.srcLang
                t.errorCount = 0
                t.skip = false
                t.provisional = r.version < t.textVersion || t.state == TrackState.TYPING
                translated++
                SessionHub.update { it.copy(translated = translated) }
            }
            else -> return
        }
        dirty += t.id
        flush()
    }

    private fun hasOverlay(t: Track): Boolean = t.translation != null && !t.skip && !labelsHidden && !excluded && !paused

    private fun flush() {
        if (dirty.isEmpty() && gone.isEmpty()) return
        val ups = ArrayList<LabelSpec>()
        val rem = ArrayList<Long>(gone)
        for (id in dirty) {
            val t = tracker.get(id)
            if (t == null) { rem += id; continue }
            val spec = specFor(t)
            if (spec == null) { t.covered = false; rem += id }
            else { t.covered = spec.text != null && hasOverlay(t); ups += spec }
        }
        dirty.clear(); gone.clear()
        overlay.update(ups, rem)
    }

    private fun specFor(t: Track): LabelSpec? {
        if (excluded || t.skip) return null
        val txt = t.translation
        if (txt == null && t.errorCount > 0) return null
        val m = mapper ?: return null
        val style = t.style ?: LabelStyle.DEFAULT
        val rtl = Languages.isRtl(cfg.target)
        val srcRtl = Languages.isRtl(t.srcLang)
        var align = t.align
        // Mirror physical alignment when the reading direction flips.
        if (srcRtl != rtl && align != HAlign.CENTER) align = if (align == HAlign.LEFT) HAlign.RIGHT else HAlign.LEFT
        val bg: Int
        val fg: Int
        when (cfg.conceal) {
            ConcealMode.BLACK -> { bg = ((cfg.bgOpacity.coerceIn(0.2f, 1f) * 255).toInt() shl 24); fg = 0xFFFFFFFF.toInt() }
            else -> { bg = (0xF5 shl 24) or (style.bg and 0xFFFFFF); fg = style.fg }
        }
        return LabelSpec(
            id = t.id, rect = m.map(t.rect), text = txt, provisional = txt != null && t.provisional,
            rtl = rtl, align = align, lineHeight = t.lineHeight * m.scaleY, lineCount = t.lineCount,
            bg = bg, fg = fg, bold = style.bold, borderless = cfg.conceal == ConcealMode.BORDERLESS,
        )
    }

    // ------------------------------------------------------------------ housekeeping

    private suspend fun housekeeping(now: Long) {
        for (t in tracker.settle(now)) {
            if (t.translation != null && t.translationVersion == t.textVersion) { t.provisional = false; dirty += t.id }
            else requestTranslation(t, false)
        }
        for (t in tracker.tracks) {
            if (t.translation == null && !t.skip && t.errorCount > 0 &&
                now - t.errorAt >= min(2000L shl min(t.errorCount - 1, 3), 15_000L)
            ) {
                t.errorAt = now
                requestTranslation(t, false)
            }
        }
        if (now - lastFgCheck > 1500) { lastFgCheck = now; evaluateExclusion() }
        if (now - lastPermCheck > 3000) {
            lastPermCheck = now
            if (!host.canDraw()) { onFatal("Overlay permission was revoked, so translation stopped."); return }
        }
        if (now - lastPolicyCheck > 5000) { lastPolicyCheck = now; refreshPolicy() }
        flush()
    }

    private fun evaluateExclusion() {
        val pkg = if (cfg.excludedApps.isNotEmpty() && ForegroundAppDetector.hasUsageAccess(app)) fgApp.current() else null
        val ex = SessionHub.uiVisible.value || (pkg != null && pkg in cfg.excludedApps)
        if (ex == excluded) return
        excluded = ex
        if (ex) {
            overlay.setHidden(true)
            clearAll()
            SessionHub.update { it.copy(ocrStatus = "Paused while this app is in front") }
        } else {
            overlay.setHidden(labelsHidden || paused)
            pendingFull = true
        }
    }

    private fun refreshPolicy() {
        val i: Intent? = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 100) ?: 100
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val plugged = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val low = level * 100 / max(1, scale) <= 20 && plugged == 0
        val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
        eco = cfg.batterySaver || low || pm.isPowerSaveMode
        hot = Build.VERSION.SDK_INT >= 29 && pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_MODERATE
        tracker.maxPeekMs = if (eco) 10_000L else 6_000L
        capture.setLongSide(longSideFor(cfg))
    }

    private companion object {
        const val PEEK_SETTLE_MS = 55L
        const val PEEK_TIMEOUT_MS = 350L
        const val PEEK_MIN_AGE_NS = 24_000_000L
    }
}
