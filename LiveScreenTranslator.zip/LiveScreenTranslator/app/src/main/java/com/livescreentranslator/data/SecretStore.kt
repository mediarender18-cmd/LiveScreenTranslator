package com.livescreentranslator.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * API keys are entered by the user at runtime and kept in Keystore-backed encrypted storage.
 * No key is ever compiled into the APK. For production use, prefer pointing the endpoint at your own
 * backend, which holds the real provider credentials.
 */
class SecretStore(ctx: Context) {
    private val prefs: SharedPreferences? = runCatching {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "secrets", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }.getOrNull()

    val available: Boolean get() = prefs != null

    fun get(id: String): String? = prefs?.getString(id, null)?.takeIf { it.isNotBlank() }

    fun has(id: String): Boolean = get(id) != null

    fun set(id: String, value: String?) {
        val e = prefs?.edit() ?: return
        if (value.isNullOrBlank()) e.remove(id) else e.putString(id, value.trim())
        e.apply()
    }
}
