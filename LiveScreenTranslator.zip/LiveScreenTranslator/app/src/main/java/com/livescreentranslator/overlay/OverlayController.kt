package com.livescreentranslator.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Chooses which kind of window we are allowed to add overlays with right now. */
class OverlayHost(private val app: Context) {
    class Target(val wm: WindowManager, val type: Int, val trusted: Boolean)

    fun target(): Target? {
        OverlayHostService.instance?.let { svc ->
            return Target(
                svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, true,
            )
        }
        if (Settings.canDrawOverlays(app)) {
            return Target(
                app.getSystemService(Context.WINDOW_SERVICE) as WindowManager,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, false,
            )
        }
        return null
    }

    fun canDraw(): Boolean = OverlayHostService.instance != null || Settings.canDrawOverlays(app)
}

/** Owns the full-screen label window. Thread-safe entry points post to the main thread. */
class OverlayController(private val ctx: Context, private val host: OverlayHost) {
    private val main = Handler(Looper.getMainLooper())
    private var view: OverlayView? = null
    private var target: OverlayHost.Target? = null
    private var params: WindowManager.LayoutParams? = null

    /** Must be called on the main thread. Returns false when no overlay window can be created. */
    fun attach(strongConceal: Boolean): Boolean {
        if (view != null) return true
        val t = host.target() ?: return false
        val v = OverlayView(ctx)
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, t.type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        )
        p.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 30) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        applyAlpha(p, t, strongConceal)
        return try {
            t.wm.addView(v, p)
            view = v; target = t; params = p
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Android 12+ blocks touches that pass through an untrusted overlay with window alpha above 0.8.
     * Without the accessibility host we trade a little concealment strength for working taps, unless
     * the user chose strong concealment.
     */
    private fun applyAlpha(p: WindowManager.LayoutParams, t: OverlayHost.Target, strong: Boolean) {
        p.alpha = if (!t.trusted && Build.VERSION.SDK_INT >= 31 && !strong) 0.8f else 1f
    }

    fun setStrongConceal(strong: Boolean) = main.post {
        val v = view ?: return@post
        val p = params ?: return@post
        val t = target ?: return@post
        applyAlpha(p, t, strong)
        runCatching { t.wm.updateViewLayout(v, p) }
    }

    fun detach() {
        val run = Runnable {
            view?.let { v -> runCatching { target?.wm?.removeView(v) } }
            view = null; params = null; target = null
        }
        if (Looper.myLooper() == Looper.getMainLooper()) run.run() else main.post(run)
    }

    fun update(upserts: List<LabelSpec>, removes: Collection<Long>) {
        if (upserts.isEmpty() && removes.isEmpty()) return
        val u = ArrayList(upserts)
        val r = ArrayList(removes)
        main.post { view?.applySpecs(u, r) }
    }

    fun clear() = main.post { view?.clear() }
    fun setHidden(h: Boolean) = main.post { view?.setHidden(h) }
    fun setConfig(c: OverlayConfig) = main.post { view?.setConfig(c) }

    /** Suspends until the hide/show has been applied on the main thread. */
    suspend fun setPeekHidden(ids: Set<Long>, hidden: Boolean) =
        withContext(Dispatchers.Main.immediate) { view?.setPeekHidden(ids, hidden) }
}
