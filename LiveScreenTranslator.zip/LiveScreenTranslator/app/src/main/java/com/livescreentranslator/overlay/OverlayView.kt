package com.livescreentranslator.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.text.TextUtils
import android.view.Choreographer
import android.view.View
import com.livescreentranslator.core.FRect
import com.livescreentranslator.core.HAlign
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** What the pipeline wants drawn for one piece of source text. Coordinates are screen pixels. */
data class LabelSpec(
    val id: Long,
    val rect: FRect,
    /** Null while waiting for a translation. Nothing covers the original in that state. */
    val text: String?,
    val provisional: Boolean,
    val rtl: Boolean,
    val align: HAlign,
    val lineHeight: Float,
    val lineCount: Int,
    val bg: Int,
    val fg: Int,
    val bold: Boolean,
    val borderless: Boolean,
)

data class OverlayConfig(
    val animSpeed: Float = 1f,
    val typing: Boolean = true,
    val textScale: Float = 1f,
)

/**
 * A single full-screen, non-touchable view that draws every translated label with Canvas.
 * One window and one draw pass is far cheaper than a window per label. All methods run on the main thread.
 */
class OverlayView(ctx: Context) : View(ctx) {
    private class L(var spec: LabelSpec, val target: FRect, var cur: FRect) {
        var targetRect = target
        var enter = 0f
        var exit = 0f
        var removing = false
        var committed = ""
        var breaks = intArrayOf(0)
        var revealed = 0f
        var paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        var full: StaticLayout? = null
        var partial: StaticLayout? = null
        var partialN = -1
        var textW = 0
        var fitDirty = true
        var peekHidden = false
        val createdAt: Long = SystemClock.uptimeMillis()
    }

    private val d = resources.displayMetrics.density
    private val labels = LinkedHashMap<Long, L>()
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val loc = IntArray(2)

    private var cfg = OverlayConfig()
    private var hideAlpha = 1f
    private var hideTarget = 1f
    private var running = false
    private var lastNanos = 0L
    private var frameEma = 16f
    private var slowFrames = 0
    private var fastFrames = 0
    private var lowQuality = false

    private val frameCb = Choreographer.FrameCallback { t -> tick(t) }

    fun setConfig(c: OverlayConfig) {
        cfg = c
        labels.values.forEach { it.fitDirty = true }
        invalidate()
    }

    fun setHidden(hidden: Boolean) {
        hideTarget = if (hidden) 0f else 1f
        kick()
    }

    fun setPeekHidden(ids: Set<Long>, hidden: Boolean) {
        labels.values.forEach { if (it.spec.id in ids) it.peekHidden = hidden }
        invalidate()
    }

    fun clear() {
        labels.clear()
        invalidate()
    }

    fun applySpecs(upserts: List<LabelSpec>, removes: Collection<Long>) {
        for (id in removes) labels[id]?.let { it.removing = true }
        for (s in upserts) {
            val box = boxFor(s)
            val ex = labels[s.id]
            if (ex == null) {
                labels[s.id] = L(s, box, box).also { setText(it, s.text) }
            } else {
                val textChanged = ex.spec.text != s.text
                val styleChanged = ex.spec.rtl != s.rtl || ex.spec.align != s.align || ex.spec.bold != s.bold ||
                    ex.spec.fg != s.fg || ex.spec.lineHeight != s.lineHeight
                ex.spec = s
                ex.removing = false
                ex.exit = 0f
                if (ex.targetRect.maxEdgeDelta(box) > 0.5f) {
                    ex.targetRect = box
                    if (ex.cur.centerDistance(box) > 3f * max(box.height, 24f)) ex.cur = box
                    ex.fitDirty = true
                }
                if (textChanged) setText(ex, s.text)
                if (styleChanged) ex.fitDirty = true
            }
        }
        kick()
    }

    private fun boxFor(s: LabelSpec): FRect {
        val pad = if (s.borderless) 1.5f * d else min(4f * d, s.rect.height * 0.25f)
        return s.rect.inflate(pad)
    }

    private fun setText(l: L, text: String?) {
        val old = l.committed
        val new = text ?: ""
        l.committed = new
        l.breaks = RevealMath.breaks(new)
        l.fitDirty = true
        l.partialN = -1
        l.revealed = when {
            !cfg.typing || lowQuality -> (l.breaks.size - 1).toFloat()
            old.isEmpty() -> 0f
            else -> min(l.revealed, RevealMath.commonPrefixGraphemes(old, new).toFloat())
        }
    }

    private fun newLayout(text: CharSequence, paint: TextPaint, width: Int, s: LabelSpec, maxLines: Int): StaticLayout {
        val align = when (s.align) {
            HAlign.CENTER -> Layout.Alignment.ALIGN_CENTER
            HAlign.LEFT -> if (s.rtl) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL
            HAlign.RIGHT -> if (s.rtl) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_OPPOSITE
        }
        return StaticLayout.Builder.obtain(text, 0, text.length, paint, max(width, 8))
            .setAlignment(align)
            .setTextDirection(if (s.rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.LTR)
            .setIncludePad(false)
            .setMaxLines(maxLines)
            .setEllipsize(TextUtils.TruncateAt.END)
            .build()
    }

    /** Finds the largest text size (near the original's) at which the translation fits inside the label box. */
    private fun fit(l: L) {
        val s = l.spec
        val text = l.committed
        l.fitDirty = false
        l.partialN = -1
        if (text.isEmpty()) { l.full = null; return }
        val box = l.targetRect
        val inner = if (s.borderless) 0f else 1.5f * d
        val width = (box.width - 2 * inner).toInt()
        val height = box.height
        val base = max(s.lineHeight * 0.92f * cfg.textScale, 8f * d)
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        paint.typeface = if (s.bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        paint.color = s.fg
        var lo = base * 0.5f
        var hi = base * 1.15f
        var best = lo
        repeat(7) {
            val mid = (lo + hi) / 2f
            paint.textSize = mid
            val lay = newLayout(text, paint, width, s, Int.MAX_VALUE)
            val fits = lay.height <= height * 1.02f && widest(lay) <= width + 1
            if (fits) { best = mid; lo = mid } else hi = mid
        }
        paint.textSize = best
        var lay = newLayout(text, paint, width, s, Int.MAX_VALUE)
        if (lay.height > height * 1.02f || widest(lay) > width + 1) {
            val lineH = max(1f, lay.height.toFloat() / max(1, lay.lineCount))
            lay = newLayout(text, paint, width, s, max(1, (height / lineH).toInt()))
        }
        l.paint = paint
        l.full = lay
        l.textW = width
    }

    private fun widest(lay: StaticLayout): Float {
        var m = 0f
        for (i in 0 until lay.lineCount) m = max(m, lay.getLineWidth(i))
        return m
    }

    private fun kick() {
        if (!running) {
            running = true
            lastNanos = 0L
            Choreographer.getInstance().postFrameCallback(frameCb)
        }
        invalidate()
    }

    private fun ease(x: Float): Float { val k = 1f - x.coerceIn(0f, 1f); return 1f - k * k * k }

    private fun tick(nanos: Long) {
        val dt = if (lastNanos == 0L) 0.016f else ((nanos - lastNanos) / 1e9f).coerceIn(0f, 0.05f)
        lastNanos = nanos
        // Adaptive quality: drop typing and vertical motion when frames are consistently slow.
        frameEma += (dt * 1000f - frameEma) * 0.1f
        if (frameEma > 26f) { slowFrames++; fastFrames = 0 } else if (frameEma < 18f) { fastFrames++; slowFrames = 0 }
        if (!lowQuality && slowFrames > 30) lowQuality = true
        if (lowQuality && fastFrames > 120) lowQuality = false

        val speed = cfg.animSpeed.coerceIn(0.3f, 3f)
        var busy = false

        if (hideAlpha != hideTarget) {
            val step = dt / (0.18f / speed)
            hideAlpha = if (hideAlpha < hideTarget) min(hideTarget, hideAlpha + step) else max(hideTarget, hideAlpha - step)
            busy = true
        }
        val it = labels.values.iterator()
        while (it.hasNext()) {
            val l = it.next()
            if (l.removing) {
                l.exit += dt / (0.15f / speed)
                if (l.exit >= 1f) { it.remove(); continue }
                busy = true
            } else if (l.enter < 1f) {
                l.enter = min(1f, l.enter + dt / (0.22f / speed))
                busy = true
            }
            if (l.cur != l.targetRect) {
                val f = 1f - exp(-dt * 14f * speed)
                l.cur = l.cur.lerp(l.targetRect, f)
                if (l.cur.maxEdgeDelta(l.targetRect) < 0.5f) l.cur = l.targetRect
                busy = true
            }
            val total = l.breaks.size - 1
            if (l.revealed < total) {
                if (!cfg.typing || lowQuality) l.revealed = total.toFloat()
                else if (l.enter > 0.25f) l.revealed = min(total.toFloat(), l.revealed + RevealMath.charsPerSecond(total, speed) * dt)
                busy = true
            }
        }
        invalidate()
        if (busy) Choreographer.getInstance().postFrameCallback(frameCb) else running = false
    }

    private fun pulsing(): Boolean = labels.values.any { !it.removing && (it.spec.text == null || it.spec.provisional) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (hideAlpha <= 0.01f || labels.isEmpty()) return
        getLocationOnScreen(loc)
        val now = SystemClock.uptimeMillis()
        for (l in labels.values) {
            if (l.peekHidden) continue
            val s = l.spec
            val prog = ease(l.enter) * (1f - l.exit) * hideAlpha
            if (prog <= 0.01f) continue
            val r = l.cur
            val dx = -loc[0].toFloat()
            val dy = -loc[1].toFloat() + if (lowQuality) 0f else (1f - ease(l.enter)) * 6f * d

            if (s.text == null) {
                // Loading marker only if the translation is genuinely late; nothing covers the original yet.
                if (now - l.createdAt > 400) drawDots(canvas, r.right + dx - 12f * d, r.top + dy + 5f * d, prog * 0.8f, now)
                continue
            }
            if (l.fitDirty) fit(l)
            val lay = l.full ?: continue

            val corner = if (s.borderless) 0f else min(6f * d, r.height * 0.3f)
            bgPaint.color = s.bg
            bgPaint.alpha = ((s.bg ushr 24) * prog).toInt().coerceIn(0, 255)
            canvas.drawRoundRect(r.left + dx, r.top + dy, r.right + dx, r.bottom + dy, corner, corner, bgPaint)

            val n = l.revealed.toInt().coerceIn(0, l.breaks.size - 1)
            if (n > 0) {
                val shown: StaticLayout = if (n >= l.breaks.size - 1) lay else {
                    if (l.partialN != n) {
                        l.partial = newLayout(l.committed.substring(0, l.breaks[n]), l.paint, l.textW, s, Int.MAX_VALUE)
                        l.partialN = n
                    }
                    l.partial ?: lay
                }
                l.paint.alpha = (255 * prog).toInt().coerceIn(0, 255)
                val inner = if (s.borderless) 0f else 1.5f * d
                canvas.save()
                canvas.translate(r.left + dx + inner, r.top + dy + (r.height - lay.height) / 2f)
                canvas.clipRect(0f, -r.height, l.textW.toFloat(), r.height * 2f)
                shown.draw(canvas)
                canvas.restore()
            }
            if (s.provisional) drawDots(canvas, r.right + dx - 12f * d, r.bottom + dy - 4f * d, prog * 0.7f, now)
        }
        if (pulsing()) postInvalidateDelayed(90)
    }

    /** Three softly pulsing dots. Used for "translating…" and for provisional (not yet final) translations. */
    private fun drawDots(c: Canvas, x: Float, y: Float, a: Float, now: Long) {
        for (i in 0 until 3) {
            val p = 0.5f + 0.5f * sin(now / 260.0 + i * 0.8).toFloat()
            dotPaint.color = 0xFF22D3EE.toInt()
            dotPaint.alpha = ((60 + 150 * p) * a).toInt().coerceIn(0, 255)
            c.drawCircle(x + i * 5f * d, y, 1.6f * d, dotPaint)
        }
    }

    override fun onDetachedFromWindow() {
        Choreographer.getInstance().removeFrameCallback(frameCb)
        running = false
        super.onDetachedFromWindow()
    }
}
