package com.livescreentranslator.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.livescreentranslator.LstApp
import com.livescreentranslator.R
import com.livescreentranslator.capture.CaptureEngine
import com.livescreentranslator.overlay.FloatingWidget
import com.livescreentranslator.overlay.OverlayController
import com.livescreentranslator.overlay.OverlayHost
import com.livescreentranslator.ui.MainActivity

/**
 * Foreground service (type mediaProjection) that owns the capture session. Everything is torn down
 * the moment the user taps Stop, revokes the projection from the system UI, or loses overlay permission.
 */
class TranslationService : Service() {
    companion object {
        const val ACTION_START = "com.livescreentranslator.START"
        const val ACTION_STOP = "com.livescreentranslator.STOP"
        const val ACTION_PAUSE = "com.livescreentranslator.PAUSE"
        const val ACTION_TOGGLE_LABELS = "com.livescreentranslator.TOGGLE_LABELS"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL = "session"
        private const val NOTIF_ID = 42

        fun intent(ctx: Context, action: String) = Intent(ctx, TranslationService::class.java).setAction(action)
    }

    private var capture: CaptureEngine? = null
    private var overlay: OverlayController? = null
    private var widget: FloatingWidget? = null
    private var pipeline: Pipeline? = null
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_STOP -> shutdown(null)
            ACTION_PAUSE -> togglePause()
            ACTION_TOGGLE_LABELS -> toggleLabels()
            else -> if (!running) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        if (running) return
        // startForeground must be called promptly after startForegroundService, before anything can fail.
        beginForeground(paused = false)
        SessionHub.update { it.copy(phase = Phase.STARTING, message = null) }

        val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        @Suppress("DEPRECATION")
        val data: Intent? = intent.getParcelableExtra(EXTRA_RESULT_DATA)
        if (data == null) { shutdown("Screen capture permission data was missing."); return }

        val graph = (application as LstApp).graph
        val host = OverlayHost(applicationContext)
        if (!host.canDraw()) { shutdown("Allow “Display over other apps” first."); return }

        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = mpm.getMediaProjection(code, data)
                ?: run { shutdown("Android did not grant screen capture."); return }

            val ov = OverlayController(applicationContext, host)
            if (!ov.attach(graph.settingsNow().strongConceal)) { projection.stop(); shutdown("Couldn't create the overlay window."); return }
            val cap = CaptureEngine(applicationContext)
            overlay = ov; capture = cap

            val pl = Pipeline(application, graph, cap, ov, host) { msg -> shutdown(msg) }
            pipeline = pl
            cap.start(projection, 1600, onSizeChanged = {}, onStopped = { shutdown(null) })

            val w = FloatingWidget(applicationContext, host, object : FloatingWidget.Callbacks {
                override fun onPause() = togglePause()
                override fun onHide() = toggleLabels()
                override fun onSettings() {
                    startActivity(Intent(applicationContext, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        .putExtra(MainActivity.EXTRA_OPEN_SETTINGS, true))
                }
                override fun onStop() = shutdown(null)
            })
            w.show()
            widget = w

            running = true
            SessionHub.update {
                SessionState(phase = Phase.RUNNING, startedAt = SystemClock.elapsedRealtime(), ocrStatus = "Starting…")
            }
            pl.start()
        } catch (e: SecurityException) {
            shutdown("Android refused the screen capture session: ${e.message}")
        } catch (e: Exception) {
            shutdown("Couldn't start translation: ${e.message}")
        }
    }

    private fun togglePause() {
        val pl = pipeline ?: return
        val p = !pl.paused
        pl.setPaused(p)
        widget?.setState(p, pl.labelsHidden)
        beginForeground(p)
    }

    private fun toggleLabels() {
        val pl = pipeline ?: return
        pl.toggleLabels()
        widget?.setState(pl.paused, pl.labelsHidden)
    }

    private fun shutdown(error: String?) {
        running = false
        pipeline?.stop(); pipeline = null
        widget?.hide(); widget = null
        overlay?.detach(); overlay = null
        capture?.stop(); capture = null
        SessionHub.reset()
        if (error != null) SessionHub.update { it.copy(phase = Phase.ERROR, message = error) }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (running) shutdown(null)
        super.onDestroy()
    }

    // ------------------------------------------------------------------ notification

    private fun beginForeground(paused: Boolean) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Live translation session", NotificationManager.IMPORTANCE_LOW))
        }
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(paused), type)
    }

    private fun buildNotification(paused: Boolean): Notification {
        fun pi(action: String, req: Int) = PendingIntent.getService(
            this, req, intent(this, action), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_translate)
            .setContentTitle(if (paused) "Live translation paused" else "Live translation is capturing your screen")
            .setContentText("Tap Stop at any time. Frames are processed on this device.")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .addAction(0, if (paused) "Resume" else "Pause", pi(ACTION_PAUSE, 1))
            .addAction(0, "Stop", pi(ACTION_STOP, 2))
            .build()
    }
}
