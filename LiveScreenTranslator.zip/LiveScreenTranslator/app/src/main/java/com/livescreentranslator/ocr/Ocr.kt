package com.livescreentranslator.ocr

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.livescreentranslator.core.FRect
import com.livescreentranslator.core.HAlign
import com.livescreentranslator.core.OcrUnit
import com.livescreentranslator.core.SelfLabel
import com.livescreentranslator.core.TextUtil
import kotlinx.coroutines.tasks.await
import kotlin.math.abs
import kotlin.math.max

/** Scripts the bundled ML Kit recognisers can read. Arabic, Persian, Cyrillic, Thai, Greek etc. are NOT available. */
enum class OcrScript { LATIN, CHINESE, JAPANESE, KOREAN, DEVANAGARI }

interface OcrEngine {
    /** Recognises text in [bitmap]; results are shifted by ([ox], [oy]) so they are in full-frame coordinates. */
    suspend fun recognize(bitmap: Bitmap, script: OcrScript, ox: Float, oy: Float, frameW: Float): List<OcrUnit>
    fun close()
}

data class LineBox(val text: String, val rect: FRect, val conf: Float)

/** Splits an ML Kit block into paragraphs so that stacked menu entries are not merged into one "sentence". */
object ParagraphSplitter {
    fun split(lines: List<LineBox>): List<List<LineBox>> {
        if (lines.size <= 1) return listOf(lines)
        val maxW = lines.maxOf { it.rect.width }
        val out = ArrayList<List<LineBox>>()
        var cur = ArrayList<LineBox>().apply { add(lines[0]) }
        for (i in 1 until lines.size) {
            val prev = lines[i - 1]
            val line = lines[i]
            val gap = line.rect.top - prev.rect.bottom
            val lh = max(prev.rect.height, line.rect.height)
            // A wrapped line fills (almost) the whole block width, is followed closely by its continuation,
            // and the continuation does not start a new capitalised item. Menu entries fail at least one test.
            val prevFull = prev.rect.width >= 0.75f * maxW
            val tight = gap <= 0.6f * lh
            val aligned = abs(line.rect.left - prev.rect.left) < lh * 1.2f ||
                abs(line.rect.centerX - prev.rect.centerX) < lh * 1.2f
            val startsNewItem = line.text.trimStart().firstOrNull()?.isUpperCase() == true
            if (prevFull && tight && aligned && !startsNewItem) cur.add(line) else {
                out.add(cur); cur = ArrayList<LineBox>().apply { add(line) }
            }
        }
        out.add(cur)
        return out
    }
}

object UnitBuilder {
    fun alignOf(lines: List<FRect>, frameW: Float): HAlign {
        if (lines.size == 1) {
            return if (abs(lines[0].centerX - frameW / 2f) < frameW * 0.04f) HAlign.CENTER else HAlign.LEFT
        }
        fun spread(v: List<Float>) = (v.maxOrNull() ?: 0f) - (v.minOrNull() ?: 0f)
        val l = spread(lines.map { it.left })
        val r = spread(lines.map { it.right })
        val c = spread(lines.map { it.centerX })
        return if (l <= r && l <= c) HAlign.LEFT else if (r <= c) HAlign.RIGHT else HAlign.CENTER
    }

    fun join(lines: List<LineBox>): String {
        val sb = StringBuilder()
        for ((i, l) in lines.withIndex()) {
            val t = l.text.trim()
            if (i > 0 && sb.isNotEmpty()) {
                val ideo = TextUtil.isIdeographic(sb.last()) || (t.isNotEmpty() && TextUtil.isIdeographic(t.first()))
                if (!ideo) sb.append(' ')
            }
            sb.append(t)
        }
        return sb.toString()
    }

    fun build(lines: List<LineBox>, frameW: Float): List<OcrUnit> =
        ParagraphSplitter.split(lines).filter { it.isNotEmpty() }.map { para ->
            val rects = para.map { it.rect }
            val box = FRect.unionAll(rects)!!
            val text = join(para)
            OcrUnit(
                text = text,
                rect = box,
                confidence = para.map { it.conf }.average().toFloat(),
                lineCount = para.size,
                lineHeight = rects.map { it.height }.average().toFloat(),
                align = alignOf(rects, frameW),
                vertical = para.size == 1 && box.height > 2.2f * box.width && text.length >= 2,
            )
        }
}

class MlKitOcrEngine : OcrEngine {
    private val clients = HashMap<OcrScript, TextRecognizer>()

    private fun client(s: OcrScript): TextRecognizer = clients.getOrPut(s) {
        when (s) {
            OcrScript.LATIN -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            OcrScript.CHINESE -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            OcrScript.JAPANESE -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
            OcrScript.KOREAN -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            OcrScript.DEVANAGARI -> TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        }
    }

    override suspend fun recognize(bitmap: Bitmap, script: OcrScript, ox: Float, oy: Float, frameW: Float): List<OcrUnit> {
        val result: Text = client(script).process(InputImage.fromBitmap(bitmap, 0)).await()
        val out = ArrayList<OcrUnit>()
        for (block in result.textBlocks) {
            val lines = block.lines.mapNotNull { l ->
                val b = l.boundingBox ?: return@mapNotNull null
                LineBox(
                    l.text,
                    FRect(b.left + ox, b.top + oy, b.right + ox, b.bottom + oy),
                    l.confidence,
                )
            }
            if (lines.isNotEmpty()) out += UnitBuilder.build(lines, frameW)
        }
        return out
    }

    override fun close() {
        clients.values.forEach { runCatching { it.close() } }
        clients.clear()
    }
}

/** Drops noise, protected-by-rule text (numbers, URLs), vertical text, and anything under our own labels. */
class OcrPostProcessor(var minConfidence: Float = 0.5f) {
    fun process(units: List<OcrUnit>, frameW: Int, frameH: Int, selfLabels: List<SelfLabel>): List<OcrUnit> {
        val frameArea = frameW.toFloat() * frameH
        val kept = units.filter { u ->
            u.confidence >= minConfidence &&
                u.rect.height >= 7f &&
                u.rect.area < frameArea * 0.6f &&
                !u.vertical &&
                TextUtil.shouldTranslate(u.text) &&
                !isSelf(u, selfLabels)
        }
        val out = ArrayList<OcrUnit>()
        for (u in kept.sortedByDescending { it.confidence }) {
            if (out.none { it.rect.iou(u.rect) > 0.8f }) out += u
        }
        return out.sortedWith(compareBy({ it.rect.top }, { it.rect.left }))
    }

    private fun isSelf(u: OcrUnit, labels: List<SelfLabel>): Boolean =
        labels.any { it.rect.inflate(4f).contains(u.rect.centerX, u.rect.centerY) }
}
