package com.livescreentranslator.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class Phase { IDLE, STARTING, RUNNING, PAUSED, ERROR }

data class SessionState(
    val phase: Phase = Phase.IDLE,
    /** SystemClock.elapsedRealtime() when the session began. */
    val startedAt: Long = 0L,
    val detected: Int = 0,
    val translated: Int = 0,
    val ocrStatus: String = "Idle",
    val engineStatus: String = "Ready",
    val labelsHidden: Boolean = false,
    val message: String? = null,
    val lastOcrMs: Int = 0,
)

/** Process-wide session state shared by the service, pipeline and Compose UI. */
object SessionHub {
    private val _state = MutableStateFlow(SessionState())
    val state: StateFlow<SessionState> = _state.asStateFlow()

    /** True while our own UI is on screen: the overlay stays out of the way of the app's own settings. */
    val uiVisible = MutableStateFlow(false)

    fun update(f: (SessionState) -> SessionState) = _state.update(f)
    fun reset() { _state.value = SessionState() }
}
