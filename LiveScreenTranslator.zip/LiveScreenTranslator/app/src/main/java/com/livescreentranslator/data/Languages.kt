package com.livescreentranslator.data

import com.livescreentranslator.ocr.OcrScript
import java.util.Locale

data class Language(
    val code: String,
    val name: String,
    val native: String,
    val rtl: Boolean,
    /** Script the bundled OCR can read for this language as a *source*; null = OCR not supported. */
    val ocr: OcrScript?,
)

/**
 * The 59 languages supported by ML Kit on-device translation. Online providers may support more,
 * but the picker is limited to what the offline engine can also handle so fallbacks stay valid.
 */
object Languages {
    const val AUTO = "auto"

    // code|English name|native name|rtl(0/1)|ocr script (L latin, C chinese, J japanese, K korean, D devanagari, - none)
    private const val RAW = """
af|Afrikaans|Afrikaans|0|L
ar|Arabic|العربية|1|-
be|Belarusian|Беларуская|0|-
bg|Bulgarian|Български|0|-
bn|Bengali|বাংলা|0|-
ca|Catalan|Català|0|L
cs|Czech|Čeština|0|L
cy|Welsh|Cymraeg|0|L
da|Danish|Dansk|0|L
de|German|Deutsch|0|L
el|Greek|Ελληνικά|0|-
en|English|English|0|L
eo|Esperanto|Esperanto|0|L
es|Spanish|Español|0|L
et|Estonian|Eesti|0|L
fa|Persian|فارسی|1|-
fi|Finnish|Suomi|0|L
fr|French|Français|0|L
ga|Irish|Gaeilge|0|L
gl|Galician|Galego|0|L
gu|Gujarati|ગુજરાતી|0|-
he|Hebrew|עברית|1|-
hi|Hindi|हिन्दी|0|D
hr|Croatian|Hrvatski|0|L
ht|Haitian Creole|Kreyòl ayisyen|0|L
hu|Hungarian|Magyar|0|L
id|Indonesian|Bahasa Indonesia|0|L
is|Icelandic|Íslenska|0|L
it|Italian|Italiano|0|L
ja|Japanese|日本語|0|J
ka|Georgian|ქართული|0|-
kn|Kannada|ಕನ್ನಡ|0|-
ko|Korean|한국어|0|K
lt|Lithuanian|Lietuvių|0|L
lv|Latvian|Latviešu|0|L
mk|Macedonian|Македонски|0|-
mr|Marathi|मराठी|0|D
ms|Malay|Bahasa Melayu|0|L
mt|Maltese|Malti|0|L
nl|Dutch|Nederlands|0|L
no|Norwegian|Norsk|0|L
pl|Polish|Polski|0|L
pt|Portuguese|Português|0|L
ro|Romanian|Română|0|L
ru|Russian|Русский|0|-
sk|Slovak|Slovenčina|0|L
sl|Slovenian|Slovenščina|0|L
sq|Albanian|Shqip|0|L
sv|Swedish|Svenska|0|L
sw|Swahili|Kiswahili|0|L
ta|Tamil|தமிழ்|0|-
te|Telugu|తెలుగు|0|-
th|Thai|ไทย|0|-
tl|Tagalog|Tagalog|0|L
tr|Turkish|Türkçe|0|L
uk|Ukrainian|Українська|0|-
ur|Urdu|اردو|1|-
vi|Vietnamese|Tiếng Việt|0|L
zh|Chinese|中文|0|C
"""

    val all: List<Language> = RAW.trim().lines().filter { it.isNotBlank() }.map { line ->
        val p = line.split("|")
        Language(
            code = p[0], name = p[1], native = p[2], rtl = p[3] == "1",
            ocr = when (p[4]) {
                "L" -> OcrScript.LATIN
                "C" -> OcrScript.CHINESE
                "J" -> OcrScript.JAPANESE
                "K" -> OcrScript.KOREAN
                "D" -> OcrScript.DEVANAGARI
                else -> null
            },
        )
    }

    val byCode: Map<String, Language> = all.associateBy { it.code }

    fun isRtl(code: String?): Boolean = code != null && byCode[code]?.rtl == true

    fun name(code: String): String = if (code == AUTO) "Auto detect" else byCode[code]?.name ?: code

    fun defaultTarget(): String = byCode[Locale.getDefault().language]?.code ?: "en"

    fun search(query: String, includeAuto: Boolean): List<Language> {
        val q = query.trim().lowercase()
        return all.filter {
            q.isEmpty() || it.name.lowercase().contains(q) || it.native.lowercase().contains(q) || it.code == q
        }
    }
}
