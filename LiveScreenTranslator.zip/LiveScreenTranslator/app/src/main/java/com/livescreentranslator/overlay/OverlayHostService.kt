package com.livescreentranslator.overlay

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Optional helper. It declares no event types and cannot read window content: its only purpose is to give
 * the app a window context of type TYPE_ACCESSIBILITY_OVERLAY, which Android treats as trusted, so touches
 * pass through translated labels even at full opacity (Android 12+ otherwise blocks taps through
 * overlays that are more than 80% opaque).
 */
class OverlayHostService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: OverlayHostService? = null
            private set
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
