package com.livescreentranslator.capture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min

class CapturedFrame(val image: Image, val width: Int, val height: Int) {
    private var closed = false
    val timestampNs: Long get() = image.timestamp

    @Synchronized
    fun close() {
        if (!closed) {
            closed = true
            runCatching { image.close() }
        }
    }
}

object FrameUtil {
    /** Copies the RGBA frame into a Bitmap, handling row padding. The caller owns (and recycles) the result. */
    fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val rowPadding = p.rowStride - p.pixelStride * img.width
        val bw = img.width + rowPadding / p.pixelStride
        val bmp = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
        p.buffer.rewind()
        bmp.copyPixelsFromBuffer(p.buffer)
        if (bw == img.width) return bmp
        val cropped = Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
        bmp.recycle()
        return cropped
    }
}

/**
 * Owns the MediaProjection virtual display. Captures at a reduced resolution (the system scales for us),
 * pulls frames on demand rather than pushing every frame, and survives rotation / resolution changes by
 * resizing the existing virtual display (Android 14+ forbids creating a second one per projection).
 */
class CaptureEngine(private val ctx: Context) {
    private val thread = HandlerThread("lst-capture").also { it.start() }
    private val handler = Handler(thread.looper)
    private val lock = Any()
    private val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var longSide = 1600
    private var stopped = false
    private var onStopped: (() -> Unit)? = null
    private var onSizeChanged: (() -> Unit)? = null

    @Volatile
    var width = 0
        private set
    @Volatile
    var height = 0
        private set
    @Volatile
    var screenW = 0
        private set
    @Volatile
    var screenH = 0
        private set
    @Volatile
    var paused = false
        private set

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            if (displayId == Display.DEFAULT_DISPLAY) refreshSize()
        }
    }

    private data class Size(val w: Int, val h: Int, val sw: Int, val sh: Int, val dpi: Int)

    private fun computeSize(): Size {
        val sw: Int
        val sh: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val b = (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).maximumWindowMetrics.bounds
            sw = b.width(); sh = b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(m)
            sw = m.widthPixels; sh = m.heightPixels
        }
        val scale = min(1f, longSide.toFloat() / max(sw, sh))
        val w = (sw * scale).toInt().coerceAtLeast(2) and 1.inv()
        val h = (sh * scale).toInt().coerceAtLeast(2) and 1.inv()
        return Size(w, h, sw, sh, ctx.resources.configuration.densityDpi)
    }

    fun start(p: MediaProjection, longSide: Int, onSizeChanged: () -> Unit, onStopped: () -> Unit) {
        this.projection = p
        this.longSide = longSide
        this.onStopped = onStopped
        this.onSizeChanged = onSizeChanged
        // Android 14+ requires a callback to be registered before createVirtualDisplay.
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (!stopped) Handler(Looper.getMainLooper()).post { this@CaptureEngine.onStopped?.invoke() }
            }
        }, handler)
        val s = computeSize()
        width = s.w; height = s.h; screenW = s.sw; screenH = s.sh
        val r = ImageReader.newInstance(s.w, s.h, PixelFormat.RGBA_8888, 2)
        reader = r
        display = p.createVirtualDisplay(
            "LiveScreenTranslator", s.w, s.h, s.dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler,
        )
        dm.registerDisplayListener(displayListener, handler)
    }

    /** Rotation, density or quality changes: resize the existing display instead of creating a new one. */
    private fun refreshSize() {
        synchronized(lock) {
            if (stopped) return
            val d = display ?: return
            val s = computeSize()
            val changed = s.w != width || s.h != height
            screenW = s.sw; screenH = s.sh
            if (!changed) return
            val newReader = ImageReader.newInstance(s.w, s.h, PixelFormat.RGBA_8888, 2)
            d.resize(s.w, s.h, s.dpi)
            d.surface = if (paused) null else newReader.surface
            val old = reader
            reader = newReader
            width = s.w; height = s.h
            runCatching { old?.close() }
        }
        onSizeChanged?.invoke()
    }

    fun setLongSide(v: Int) {
        if (v == longSide) return
        longSide = v
        handler.post { refreshSize() }
    }

    /** Newest frame produced since the last call, or null when the screen has not changed. */
    fun acquire(): CapturedFrame? = synchronized(lock) {
        val r = reader
        if (r == null || paused || stopped) return@synchronized null
        val img = try { r.acquireLatestImage() } catch (e: IllegalStateException) { null }
        if (img == null) null else CapturedFrame(img, img.width, img.height)
    }

    /** Stops delivering frames immediately. The projection stays alive until [stop]. */
    fun pause() = synchronized(lock) {
        paused = true
        display?.surface = null
        var img = reader?.acquireLatestImage()
        while (img != null) { img.close(); img = reader?.acquireLatestImage() }
    }

    fun resume() = synchronized(lock) {
        paused = false
        display?.surface = reader?.surface
    }

    fun stop() {
        synchronized(lock) {
            if (stopped) return
            stopped = true
        }
        runCatching { dm.unregisterDisplayListener(displayListener) }
        runCatching { display?.release() }
        runCatching { reader?.close() }
        runCatching { projection?.stop() }
        display = null; reader = null; projection = null
        thread.quitSafely()
    }
}
