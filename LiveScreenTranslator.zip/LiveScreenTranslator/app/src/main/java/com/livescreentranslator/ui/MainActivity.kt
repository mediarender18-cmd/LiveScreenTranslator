package com.livescreentranslator.ui

import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat
import com.livescreentranslator.data.ThemeChoice
import com.livescreentranslator.service.SessionHub
import com.livescreentranslator.service.TranslationService
import com.livescreentranslator.ui.theme.LstTheme

/** Everything the screens need from the Activity (permission intents, session start/stop). */
interface HostActions {
    fun requestOverlay()
    fun requestNotifications()
    fun openAccessibility()
    fun openUsageAccess()
    fun startSession()
    fun stopSession()
}

class MainActivity : ComponentActivity(), HostActions {
    companion object { const val EXTRA_OPEN_SETTINGS = "open_settings" }

    private val vm: MainViewModel by viewModels()
    private val openSettings = mutableStateOf(false)

    private val captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            val i = TranslationService.intent(this, TranslationService.ACTION_START)
                .putExtra(TranslationService.EXTRA_RESULT_CODE, r.resultCode)
                .putExtra(TranslationService.EXTRA_RESULT_DATA, data)
            ContextCompat.startForegroundService(this, i)
            // Hand the screen back to whatever the user wants to translate.
            window.decorView.postDelayed({ moveTaskToBack(true) }, 500)
        } else {
            vm.say("Screen capture wasn't allowed, so nothing was started.")
        }
    }

    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refreshPerms(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        openSettings.value = intent.getBooleanExtra(EXTRA_OPEN_SETTINGS, false)
        setContent {
            val s by vm.settings.collectAsState()
            LstTheme(s?.theme ?: ThemeChoice.DARK) {
                AppRoot(vm, this, openSettings)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_OPEN_SETTINGS, false)) openSettings.value = true
    }

    override fun onResume() {
        super.onResume()
        SessionHub.uiVisible.value = true
        vm.refreshPerms(this)
    }

    override fun onPause() {
        SessionHub.uiVisible.value = false
        super.onPause()
    }

    override fun requestOverlay() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    override fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun openAccessibility() { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    override fun openUsageAccess() { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }

    override fun startSession() {
        if (!Settings.canDrawOverlays(this)) { requestOverlay(); return }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        // On Android 14+ ask for the whole screen; "share one app" would hide everything else from us.
        val intent = if (Build.VERSION.SDK_INT >= 34) {
            mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else mpm.createScreenCaptureIntent()
        captureLauncher.launch(intent)
    }

    override fun stopSession() {
        startService(TranslationService.intent(this, TranslationService.ACTION_STOP))
    }
}
