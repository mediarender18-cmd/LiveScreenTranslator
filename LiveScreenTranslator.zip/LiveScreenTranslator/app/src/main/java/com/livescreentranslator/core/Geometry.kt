package com.livescreentranslator.core

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Float rectangle with no Android dependency so all geometry logic is unit-testable on the JVM. */
data class FRect(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f
    val area: Float get() = max(0f, width) * max(0f, height)

    fun contains(x: Float, y: Float) = x >= left && x <= right && y >= top && y <= bottom
    fun intersects(o: FRect) = left < o.right && o.left < right && top < o.bottom && o.top < bottom

    fun intersectionArea(o: FRect): Float {
        val w = min(right, o.right) - max(left, o.left)
        val h = min(bottom, o.bottom) - max(top, o.top)
        return if (w <= 0f || h <= 0f) 0f else w * h
    }

    fun iou(o: FRect): Float {
        val i = intersectionArea(o)
        val u = area + o.area - i
        return if (u <= 0f) 0f else i / u
    }

    fun union(o: FRect) = FRect(min(left, o.left), min(top, o.top), max(right, o.right), max(bottom, o.bottom))
    fun inflate(dx: Float, dy: Float = dx) = FRect(left - dx, top - dy, right + dx, bottom + dy)
    fun clamp(w: Float, h: Float) =
        FRect(left.coerceIn(0f, w), top.coerceIn(0f, h), right.coerceIn(0f, w), bottom.coerceIn(0f, h))

    fun lerp(o: FRect, f: Float) = FRect(
        left + (o.left - left) * f, top + (o.top - top) * f,
        right + (o.right - right) * f, bottom + (o.bottom - bottom) * f,
    )

    fun centerDistance(o: FRect) = hypot(centerX - o.centerX, centerY - o.centerY)
    fun maxEdgeDelta(o: FRect) =
        maxOf(abs(left - o.left), abs(top - o.top), abs(right - o.right), abs(bottom - o.bottom))

    companion object {
        fun unionAll(rs: Collection<FRect>): FRect? = rs.reduceOrNull { a, b -> a.union(b) }
    }
}

/** Maps capture-space rectangles to screen/window space (and back). */
class CoordinateMapper(
    srcW: Int, srcH: Int, dstW: Int, dstH: Int,
    private val originX: Float = 0f, private val originY: Float = 0f,
) {
    val scaleX: Float = dstW.toFloat() / srcW
    val scaleY: Float = dstH.toFloat() / srcH

    fun map(r: FRect) = FRect(
        r.left * scaleX - originX, r.top * scaleY - originY,
        r.right * scaleX - originX, r.bottom * scaleY - originY,
    )

    fun unmap(r: FRect) = FRect(
        (r.left + originX) / scaleX, (r.top + originY) / scaleY,
        (r.right + originX) / scaleX, (r.bottom + originY) / scaleY,
    )
}
