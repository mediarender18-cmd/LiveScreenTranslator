package com.livescreentranslator.ui

import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.livescreentranslator.data.AppSettings
import com.livescreentranslator.data.Languages
import com.livescreentranslator.service.Phase
import com.livescreentranslator.ui.theme.AccentBrush
import com.livescreentranslator.ui.theme.Blue
import com.livescreentranslator.ui.theme.Cyan
import com.livescreentranslator.ui.theme.Danger
import com.livescreentranslator.ui.theme.Good
import com.livescreentranslator.ui.theme.Violet
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class Tab { HOME, SETTINGS, HISTORY }
enum class Sub { NONE, PACKS, ONLINE, APPS }

@Composable
fun AppRoot(vm: MainViewModel, actions: HostActions, openSettings: MutableState<Boolean>) {
    val settings by vm.settings.collectAsState()
    val s = settings
    if (s == null) { Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)); return }
    if (!s.onboardingDone) { OnboardingScreen(vm, actions, s); return }

    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    var sub by rememberSaveable { mutableStateOf(Sub.NONE) }
    var picker by rememberSaveable { mutableStateOf<Int?>(null) } // 0 = source, 1 = target
    val snack = remember { SnackbarHostState() }
    val downloaded by vm.downloaded.collectAsState()

    LaunchedEffect(openSettings.value) {
        if (openSettings.value) { tab = Tab.SETTINGS; sub = Sub.NONE; openSettings.value = false }
    }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }
    BackHandler(enabled = sub != Sub.NONE) { sub = Sub.NONE }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(tab == Tab.HOME && sub == Sub.NONE, { tab = Tab.HOME; sub = Sub.NONE }, { Icon(Icons.Rounded.Home, null) }, label = { Text("Translate") })
                NavigationBarItem(tab == Tab.HISTORY && sub == Sub.NONE, { tab = Tab.HISTORY; sub = Sub.NONE }, { Icon(Icons.Rounded.History, null) }, label = { Text("History") })
                NavigationBarItem(tab == Tab.SETTINGS || sub != Sub.NONE, { tab = Tab.SETTINGS; sub = Sub.NONE }, { Icon(Icons.Rounded.Settings, null) }, label = { Text("Settings") })
            }
        },
    ) { pad ->
        when {
            sub == Sub.PACKS -> PacksScreen(vm, s, pad) { sub = Sub.NONE }
            sub == Sub.ONLINE -> OnlineScreen(vm, s, pad) { sub = Sub.NONE }
            sub == Sub.APPS -> AppsScreen(vm, actions, s, pad) { sub = Sub.NONE }
            tab == Tab.HOME -> DashboardScreen(vm, actions, s, downloaded, pad) { picker = if (it) 0 else 1 }
            tab == Tab.HISTORY -> HistoryScreen(vm, s, pad)
            else -> SettingsScreen(vm, actions, s, downloaded, pad, onPick = { picker = if (it) 0 else 1 }, onSub = { sub = it })
        }
    }

    picker?.let { which ->
        LanguagePicker(
            isSource = which == 0,
            selected = if (which == 0) s.source else s.target,
            downloaded = downloaded,
            onSelect = { code -> vm.update { if (which == 0) it.copy(source = code) else it.copy(target = code) }; picker = null },
            onDismiss = { picker = null },
        )
    }
}

// --------------------------------------------------------------------------- onboarding

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(vm: MainViewModel, actions: HostActions, s: AppSettings) {
    val pager = rememberPagerState { 3 }
    val scope = rememberCoroutineScope()
    val perms by vm.perms.collectAsState()
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 24.dp, vertical = 48.dp)) {
        HorizontalPager(pager, Modifier.weight(1f)) { page ->
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                LogoMark(72)
                when (page) {
                    0 -> {
                        Text("Your screen, in your language", style = MaterialTheme.typography.headlineLarge)
                        Text("Live Screen Translator reads text in other apps and games and places the translation right on top of it. Pick your languages once, press Start, then forget about it. No selecting regions, no screenshots, no copy and paste.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    1 -> {
                        Text("Private by design", style = MaterialTheme.typography.headlineLarge)
                        Bullet("Reading the screen happens on this device. Frames are never saved or uploaded.")
                        Bullet("On-device translation is the default and works offline once you download a language pack.")
                        Bullet("If you choose an online provider, only the extracted text is sent, never an image. You'll be asked first and it's always shown in Settings.")
                        Bullet("Android shows a capture indicator while this runs. Stop any time from the notification or the floating button.")
                        Bullet("Apps that block screen capture (banking, DRM video) stay blank. We never try to get around that.")
                    }
                    else -> {
                        Text("Two permissions", style = MaterialTheme.typography.headlineLarge)
                        PermCard("Display over other apps", "Required. Lets translated text appear on top of other apps.", perms.overlay, "Allow") { actions.requestOverlay() }
                        PermCard("Notifications", "Recommended. Shows the persistent notification with Pause and Stop.", perms.notifications, "Allow") { actions.requestNotifications() }
                        Text("Android will also ask you to confirm screen capture each time you press Start. Optional extras (trusted overlay, per-app exclusions) are in Settings.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(3) { i ->
                    Box(Modifier.size(if (i == pager.currentPage) 22.dp else 8.dp, 8.dp).clip(CircleShape)
                        .background(if (i == pager.currentPage) Cyan else MaterialTheme.colorScheme.outline))
                }
            }
            if (pager.currentPage < 2) AccentButton("Next", { scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } })
            else AccentButton("Get started", { vm.update { it.copy(onboardingDone = true) } }, enabled = perms.overlay)
        }
    }
}

@Composable
private fun Bullet(text: String) = Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
    Box(Modifier.padding(top = 8.dp).size(6.dp).clip(CircleShape).background(Cyan))
    Text(text, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
fun PermCard(title: String, body: String, granted: Boolean, action: String, onClick: () -> Unit) {
    GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(12.dp))
            if (granted) Icon(Icons.Rounded.Check, "Granted", tint = Good) else TextButton(onClick) { Text(action) }
        }
    }
}

@Composable
fun LogoMark(size: Int = 44) {
    Canvas(Modifier.size(size.dp)) {
        val r = this.size.minDimension * 0.28f
        drawRoundRect(AccentBrush, cornerRadius = androidx.compose.ui.geometry.CornerRadius(r, r))
        val w = this.size.width
        val h = this.size.height
        drawRoundRect(Color.White, Offset(w * 0.2f, h * 0.28f), androidx.compose.ui.geometry.Size(w * 0.46f, h * 0.08f), androidx.compose.ui.geometry.CornerRadius(h * 0.04f))
        drawRoundRect(Color.White, Offset(w * 0.2f, h * 0.44f), androidx.compose.ui.geometry.Size(w * 0.30f, h * 0.08f), androidx.compose.ui.geometry.CornerRadius(h * 0.04f))
        drawRoundRect(Color(0xFF05060D), Offset(w * 0.40f, h * 0.60f), androidx.compose.ui.geometry.Size(w * 0.40f, h * 0.08f), androidx.compose.ui.geometry.CornerRadius(h * 0.04f))
        drawRoundRect(Color(0xFF05060D), Offset(w * 0.40f, h * 0.74f), androidx.compose.ui.geometry.Size(w * 0.26f, h * 0.08f), androidx.compose.ui.geometry.CornerRadius(h * 0.04f))
    }
}

// --------------------------------------------------------------------------- dashboard

private fun fmtDuration(ms: Long): String {
    val t = ms / 1000
    val h = t / 3600; val m = (t % 3600) / 60; val sec = t % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

@Composable
fun DashboardScreen(
    vm: MainViewModel, actions: HostActions, s: AppSettings, downloaded: Set<String>,
    pad: PaddingValues, onPick: (isSource: Boolean) -> Unit,
) {
    val session by vm.session.collectAsState()
    val perms by vm.perms.collectAsState()
    val active = session.phase == Phase.RUNNING || session.phase == Phase.PAUSED || session.phase == Phase.STARTING
    val elapsed by produceState(0L, session.startedAt, session.phase) {
        while (true) {
            value = if (session.startedAt > 0 && session.phase != Phase.IDLE) SystemClock.elapsedRealtime() - session.startedAt else 0L
            delay(1000)
        }
    }
    val srcLang = Languages.byCode[s.source]
    val ocrBlocked = srcLang != null && srcLang.ocr == null
    val missing = packsMissing(s, downloaded)

    Column(
        Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            LogoMark(44)
            Column(Modifier.weight(1f)) {
                Text("Live Screen Translator", style = MaterialTheme.typography.titleLarge)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PulseDot(session.phase == Phase.RUNNING)
                    Text(
                        when (session.phase) {
                            Phase.IDLE -> "Ready"
                            Phase.STARTING -> "Starting…"
                            Phase.RUNNING -> if (session.labelsHidden) "Live · labels hidden" else "Live"
                            Phase.PAUSED -> "Paused"
                            Phase.ERROR -> "Stopped"
                        },
                        style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LangButton("From", Languages.name(s.source), Modifier.weight(1f)) { onPick(true) }
                IconButton(
                    onClick = { if (s.source != Languages.AUTO) vm.update { it.copy(source = it.target, target = it.source) } },
                    enabled = s.source != Languages.AUTO,
                ) { Icon(Icons.Rounded.SwapHoriz, "Swap languages") }
                LangButton("To", Languages.name(s.target), Modifier.weight(1f)) { onPick(false) }
            }
        }

        session.message?.let {
            GlassCard { Text(it, color = Danger, style = MaterialTheme.typography.bodyMedium) }
        }
        if (!perms.overlay) {
            PermCard("Display over other apps", "Needed to show translations on top of other apps.", false, "Allow") { actions.requestOverlay() }
        }
        if (ocrBlocked) {
            GlassCard { Text("On-device text recognition can't read ${srcLang?.name} yet. Choose Auto detect or a supported source language. ${srcLang?.name} works fine as a target.", style = MaterialTheme.typography.bodyMedium) }
        }
        if (missing.isNotEmpty() && !active) {
            GlassCard {
                Text("Offline pack needed", style = MaterialTheme.typography.titleMedium)
                Text("Download ${missing.joinToString { Languages.name(it) }} in Settings → Offline language packs, or allow an online provider. Without one, nothing can be translated.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            StartButton(active = active, starting = session.phase == Phase.STARTING) {
                if (active) actions.stopSession() else actions.startSession()
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Session time", fmtDuration(elapsed), Modifier.weight(1f))
            StatTile("Text detected", session.detected.toString(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile("Translated", session.translated.toString(), Modifier.weight(1f))
            StatTile("Last scan", if (session.lastOcrMs > 0) "${session.lastOcrMs} ms" else "–", Modifier.weight(1f))
        }
        GlassCard {
            StatusLine("Text recognition", if (active) session.ocrStatus else "Ready · on-device", active)
            Spacer(Modifier.height(10.dp))
            StatusLine("Translation", if (active) session.engineStatus else engineSummary(s), active)
        }
        Spacer(Modifier.height(8.dp))
    }
}

private fun packsMissing(s: AppSettings, downloaded: Set<String>): List<String> {
    val offlineUsable = s.engine == com.livescreentranslator.data.EngineChoice.OFFLINE || !s.onlineConsent
    if (!offlineUsable) return emptyList()
    return listOf(s.source, s.target).filter { it != Languages.AUTO && it != "en" && it !in downloaded }.distinct()
}

private fun engineSummary(s: AppSettings): String = when (s.engine) {
    com.livescreentranslator.data.EngineChoice.OFFLINE -> "On-device only"
    com.livescreentranslator.data.EngineChoice.AUTO -> if (s.onlineConsent) "On-device first, online fallback" else "On-device"
    com.livescreentranslator.data.EngineChoice.GOOGLE -> "Google Cloud, on-device fallback"
    com.livescreentranslator.data.EngineChoice.LIBRE -> "LibreTranslate, on-device fallback"
}

@Composable
private fun StatusLine(label: String, value: String, live: Boolean) {
    Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PulseDot(live, Modifier.padding(top = 6.dp))
        Column {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun LangButton(label: String, value: String, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(10.dp)) {
        Text(label.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium, maxLines = 1)
    }
}

@Composable
private fun StartButton(active: Boolean, starting: Boolean, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "glow")
    val glow by t.animateFloat(0.25f, 0.6f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "g")
    Box(
        Modifier.size(200.dp).clickable(remember { MutableInteractionSource() }, null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val a = if (active) glow else 0.18f
            drawCircle(Brush.radialGradient(listOf(Violet.copy(alpha = a), Color.Transparent)), radius = size.minDimension / 2)
            drawCircle(Blue.copy(alpha = a * 0.5f), radius = size.minDimension * 0.41f, style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
        }
        Box(
            Modifier.size(148.dp).clip(CircleShape).background(if (active) Brush.linearGradient(listOf(Color(0xFF2A2C3C), Color(0xFF14151F))) else AccentBrush),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(if (active) Icons.Rounded.Stop else Icons.Rounded.PlayArrow, null, Modifier.size(44.dp), tint = if (active) Danger else Color.White)
                Text(
                    if (starting) "Starting…" else if (active) "Stop" else "Start",
                    color = Color.White, style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center,
                )
                if (!active) Text("Live translation", color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

// --------------------------------------------------------------------------- language picker

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LanguagePicker(isSource: Boolean, selected: String, downloaded: Set<String>, onSelect: (String) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = MaterialTheme.colorScheme.surface) {
        Column(Modifier.padding(horizontal = 20.dp).heightIn(max = 560.dp)) {
            Text(if (isSource) "Source language" else "Target language", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search languages") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) }, shape = RoundedCornerShape(16.dp),
            )
            Spacer(Modifier.height(8.dp))
            val list = remember(q) { Languages.search(q, isSource) }
            LazyColumn {
                if (isSource && (q.isBlank() || "auto detect".contains(q.trim().lowercase()))) {
                    item {
                        LangRow("Auto detect", "Detects each piece of text", selected == Languages.AUTO, null, true) { onSelect(Languages.AUTO) }
                    }
                }
                items(list, key = { it.code }) { l ->
                    val note = when {
                        isSource && l.ocr == null -> "No on-device OCR"
                        l.code == "en" || l.code in downloaded -> "Offline ready"
                        else -> null
                    }
                    LangRow(l.name, l.native, selected == l.code, note, !(isSource && l.ocr == null), warn = isSource && l.ocr == null) { onSelect(l.code) }
                }
                item { Spacer(Modifier.height(32.dp)) }
            }
        }
    }
}

@Composable
private fun LangRow(name: String, sub: String, selected: Boolean, note: String?, enabled: Boolean, warn: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.45f).clickable(enabled = enabled, onClick = onClick).padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(name, style = MaterialTheme.typography.titleMedium)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (note != null) Text(note, style = MaterialTheme.typography.labelSmall, color = if (warn) Danger else Good)
        if (selected) { Spacer(Modifier.width(8.dp)); Icon(Icons.Rounded.Check, "Selected", tint = Cyan) }
    }
}
