package com.livescreentranslator.track

import com.livescreentranslator.core.FRect
import com.livescreentranslator.core.HAlign
import com.livescreentranslator.core.LabelStyle
import com.livescreentranslator.core.OcrUnit
import com.livescreentranslator.core.TextUtil
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class TrackState { NEW, STABLE, TYPING }
enum class ChangeKind { NONE, MOVED, GROWING, REPLACED }

class Track(val id: Long, unit: OcrUnit, now: Long) {
    var rect: FRect = unit.rect
    var text: String = unit.text
    var norm: String = TextUtil.normalize(unit.text)
    var confidence: Float = unit.confidence
    var lineCount: Int = unit.lineCount
    var lineHeight: Float = unit.lineHeight
    var align: HAlign = unit.align

    val firstSeen: Long = now
    var verifiedAt: Long = now
    var lastGrowthAt: Long = 0L
    var misses: Int = 0
    var state: TrackState = TrackState.NEW
    /** Incremented whenever the recognised source text changes; translations are tagged with it. */
    var textVersion: Int = 0
    var peekIntervalMs: Long = TextTracker.BASE_PEEK_MS

    var translation: String? = null
    var translationVersion: Int = -1
    var provisional: Boolean = false
    var srcLang: String? = null
    var errorCount: Int = 0
    var errorAt: Long = 0L
    /** Source and target language are the same: nothing to show. */
    var skip: Boolean = false

    /** True while one of our own labels hides this text, so ordinary OCR cannot see it. */
    var covered: Boolean = false
    var style: LabelStyle? = null
}

data class TrackerDelta(
    val added: List<Track>,
    val changed: List<Pair<Track, ChangeKind>>,
    val removed: List<Track>,
)

/**
 * Matches OCR results to existing tracks so unchanged text is never re-translated and moving or typed
 * text keeps its identity. Matching runs in two passes: exact text (handles scrolling lists), then
 * fuzzy text + geometry (handles typing, in-place replacement and OCR jitter).
 */
class TextTracker(private val settleMs: Long = 450L) {
    companion object {
        const val BASE_PEEK_MS = 400L
        const val MAX_PEEK_MS = 6000L
        private const val MAX_TRACKS = 60
    }

    private val map = LinkedHashMap<Long, Track>()
    private var nextId = 1L
    var maxPeekMs: Long = MAX_PEEK_MS

    val tracks: List<Track> get() = map.values.toList()
    fun get(id: Long): Track? = map[id]

    fun clear(): List<Track> {
        val all = map.values.toList()
        map.clear()
        return all
    }

    /**
     * @param scan area that was actually scanned; only tracks inside it can be matched or declared missing.
     * @param fastExpire on a scene cut tracks vanish after one miss instead of two.
     */
    fun update(
        units: List<OcrUnit>, now: Long, scan: FRect, frameW: Float, frameH: Float, fastExpire: Boolean = false,
    ): TrackerDelta {
        val added = ArrayList<Track>()
        val changed = ArrayList<Pair<Track, ChangeKind>>()
        val removed = ArrayList<Track>()

        // Tracks covered by our own label are invisible to OCR and must not be counted as "missing".
        val cands = map.values.filter { !it.covered && it.rect.intersects(scan) }
        val usedU = BooleanArray(units.size)
        val usedT = BooleanArray(cands.size)
        val norms = units.map { TextUtil.normalize(it.text) }
        val maxMove = max(frameW, frameH) * 0.5f

        // Pass 1: identical text, nearest first.
        val exact = ArrayList<Triple<Int, Int, Float>>()
        for (ui in units.indices) for (ti in cands.indices) {
            if (cands[ti].norm == norms[ui]) {
                val d = units[ui].rect.centerDistance(cands[ti].rect)
                if (d <= maxMove) exact += Triple(ui, ti, d)
            }
        }
        exact.sortBy { it.third }
        for ((ui, ti, _) in exact) if (!usedU[ui] && !usedT[ti]) {
            usedU[ui] = true; usedT[ti] = true
            apply(cands[ti], units[ui], norms[ui], now, changed)
        }

        // Pass 2: fuzzy text + geometry.
        val fuzzy = ArrayList<Triple<Int, Int, Float>>()
        for (ui in units.indices) if (!usedU[ui]) for (ti in cands.indices) if (!usedT[ti]) {
            val s = score(units[ui], norms[ui], cands[ti])
            if (s >= 0.4f) fuzzy += Triple(ui, ti, s)
        }
        fuzzy.sortByDescending { it.third }
        for ((ui, ti, _) in fuzzy) if (!usedU[ui] && !usedT[ti]) {
            usedU[ui] = true; usedT[ti] = true
            apply(cands[ti], units[ui], norms[ui], now, changed)
        }

        for (ti in cands.indices) if (!usedT[ti]) {
            val t = cands[ti]
            t.misses++
            if (fastExpire || t.misses >= 2) {
                map.remove(t.id)
                removed += t
            }
        }
        for (ui in units.indices) if (!usedU[ui] && map.size < MAX_TRACKS) {
            val t = Track(nextId++, units[ui], now)
            map[t.id] = t
            added += t
        }
        return TrackerDelta(added, changed, removed)
    }

    /** Typing has stopped for long enough: these tracks are now final and deserve a non-provisional translation. */
    fun settle(now: Long): List<Track> =
        map.values.filter { it.state == TrackState.TYPING && now - it.lastGrowthAt >= settleMs }
            .onEach { it.state = TrackState.STABLE }

    private fun score(u: OcrUnit, n: String, t: Track): Float {
        val iou = u.rect.iou(t.rect)
        val hmax = max(u.rect.height, t.rect.height)
        val near = abs(u.rect.left - t.rect.left) < 0.6f * max(u.rect.width, t.rect.width) + hmax &&
            (abs(u.rect.top - t.rect.top) < 1.5f * hmax || abs(u.rect.centerY - t.rect.centerY) < 1.2f * hmax)
        val geo = max(iou, if (near) 0.5f else 0f)
        if (geo <= 0f) return 0f
        val sim = max(TextUtil.similarity(n, t.norm), if (TextUtil.isGrowth(t.norm, n)) 0.9f else 0f)
        return 0.5f * geo + 0.5f * sim
    }

    private fun apply(t: Track, u: OcrUnit, n: String, now: Long, changed: MutableList<Pair<Track, ChangeKind>>) {
        var kind = ChangeKind.NONE
        if (n != t.norm) {
            val sim = TextUtil.similarity(n, t.norm)
            val growth = TextUtil.isGrowth(t.norm, n)
            // Tiny OCR jitter ("OPT1ONS" vs "OPTIONS") must not trigger a re-translation; changed digits always count.
            val noise = !growth && sim >= 0.85f && abs(n.length - t.norm.length) <= 1 &&
                TextUtil.digits(n) == TextUtil.digits(t.norm)
            if (!noise) {
                kind = if (growth) ChangeKind.GROWING else ChangeKind.REPLACED
                t.text = u.text
                t.norm = n
                t.textVersion++
                t.peekIntervalMs = BASE_PEEK_MS
                if (growth) { t.lastGrowthAt = now; t.state = TrackState.TYPING } else t.state = TrackState.NEW
            }
        }
        if (kind == ChangeKind.NONE) {
            if (t.state == TrackState.NEW && now - t.firstSeen > 250) t.state = TrackState.STABLE
            t.peekIntervalMs = min(maxPeekMs, (t.peekIntervalMs * 1.7f).toLong())
        }
        if (t.rect.maxEdgeDelta(u.rect) > 2.5f) {
            t.rect = u.rect
            if (kind == ChangeKind.NONE) kind = ChangeKind.MOVED
        }
        t.confidence = u.confidence
        t.lineCount = u.lineCount
        t.lineHeight = u.lineHeight
        t.align = u.align
        t.verifiedAt = now
        t.misses = 0
        if (kind != ChangeKind.NONE) changed += t to kind
    }
}
