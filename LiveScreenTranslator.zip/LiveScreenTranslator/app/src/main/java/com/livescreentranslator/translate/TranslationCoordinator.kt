package com.livescreentranslator.translate

import com.livescreentranslator.data.Languages
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

data class TranslationRequest(
    val trackId: Long, val version: Int, val text: String,
    val provisional: Boolean, val priority: Int, val delayMs: Long = 0,
)

data class TranslationResult(
    val trackId: Long, val version: Int, val text: String,
    val translated: String?, val srcLang: String?, val engine: String?,
    val error: ErrorKind?, val sameLanguage: Boolean = false, val fromCache: Boolean = false,
)

data class EngineStatus(val label: String, val ok: Boolean)
data class LangPair(val source: String, val target: String)

interface TranslationStore {
    suspend fun find(src: String, tgt: String, text: String): String?
    suspend fun save(src: String, tgt: String, text: String, out: String, engine: String)
}

/** In-memory LRU in front of an optional persistent translation memory (short labels only are read from disk). */
class TranslationCache(private val store: TranslationStore?, private val capacity: Int = 600) {
    private val lru = object : LinkedHashMap<String, String>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?) = size > capacity
    }

    private fun key(s: String, t: String, x: String) = "$s\u0000$t\u0000$x"

    suspend fun get(s: String, t: String, text: String): String? {
        val k = key(s, t, text)
        synchronized(lru) { lru[k] }?.let { return it }
        if (store != null && text.length <= 80) {
            val hit = runCatching { store.find(s, t, text) }.getOrNull()
            if (hit != null) synchronized(lru) { lru[k] = hit }
            return hit
        }
        return null
    }

    suspend fun put(s: String, t: String, text: String, out: String, engine: String) {
        synchronized(lru) { lru[key(s, t, text)] = out }
        if (text.length <= 400) runCatching { store?.save(s, t, text, out, engine) }
    }
}

/**
 * Queues translation work with: de-duplication (identical text from several tracks = one request),
 * obsolete-request cancellation (a newer version of a track supersedes the old one), a bounded queue,
 * priorities (short UI labels first, then newest), debounce for provisional text, batching,
 * provider fallback and per-provider cool-downs for rate limits and outages.
 */
class TranslationCoordinator(
    private val scope: CoroutineScope,
    private val providers: () -> List<TranslationProvider>,
    private val pair: () -> LangPair,
    private val detect: suspend (String) -> String?,
    private val cache: TranslationCache,
    private val now: () -> Long = { System.currentTimeMillis() },
    private val maxBatch: Int = 6,
    private val maxPending: Int = 48,
) {
    val results = Channel<TranslationResult>(256, BufferOverflow.DROP_OLDEST)
    val status = MutableStateFlow(EngineStatus("Ready", true))

    private class Target(val trackId: Long, val version: Int, val provisional: Boolean)
    private class Pending(
        val key: String, val text: String, var priority: Int, var readyAt: Long,
        val enqueuedAt: Long, val targets: MutableList<Target>,
    )

    private val lock = Any()
    private val pending = LinkedHashMap<String, Pending>()
    private val latest = HashMap<Long, Int>()
    private val wake = Channel<Unit>(Channel.CONFLATED)
    private val cooldown = HashMap<String, Long>()
    private var lastDetected: String? = null
    private var job: Job? = null

    fun start() { job = scope.launch { worker() } }
    fun stop() { job?.cancel() }

    fun cancel(trackId: Long) { synchronized(lock) { latest.remove(trackId) } }

    fun reset() {
        synchronized(lock) { pending.clear(); latest.clear(); cooldown.clear() }
    }

    suspend fun submit(req: TranslationRequest) {
        val p = pair()
        synchronized(lock) { latest[req.trackId] = req.version }
        val cached = cache.get(p.source, p.target, req.text)
        if (cached != null) {
            results.trySend(TranslationResult(req.trackId, req.version, req.text, cached, null, "cache", null, fromCache = true))
            return
        }
        synchronized(lock) {
            val key = "${p.source}\u0000${p.target}\u0000${req.text}"
            val t = now()
            val target = Target(req.trackId, req.version, req.provisional)
            val ex = pending[key]
            if (ex != null) {
                ex.targets.removeAll { it.trackId == req.trackId }
                ex.targets += target
                ex.priority = maxOf(ex.priority, req.priority)
                ex.readyAt = minOf(ex.readyAt, t + req.delayMs)
            } else {
                pending[key] = Pending(key, req.text, req.priority, t + req.delayMs, t, mutableListOf(target))
            }
            // Anything older queued for the same track is obsolete now.
            pending.values.forEach { if (it.key != key) it.targets.removeAll { x -> x.trackId == req.trackId } }
            pending.values.removeAll { it.targets.isEmpty() }
            while (pending.size > maxPending) {
                val victim = pending.values.filter { it.key != key }
                    .minWithOrNull(compareBy<Pending>({ it.priority }, { it.enqueuedAt })) ?: break
                pending.remove(victim.key)
            }
        }
        wake.trySend(Unit)
    }

    private suspend fun worker() {
        while (currentCoroutineContext().isActive) {
            var wait: Long? = null
            val batch: List<Pending> = synchronized(lock) {
                val t = now()
                val ready = pending.values.filter { it.readyAt <= t }
                    .sortedWith(compareByDescending<Pending> { it.priority }.thenByDescending { it.enqueuedAt })
                if (ready.isEmpty()) {
                    wait = pending.values.minOfOrNull { it.readyAt }?.minus(t)
                    emptyList()
                } else ready.take(maxBatch).also { b -> b.forEach { pending.remove(it.key) } }
            }
            if (batch.isEmpty()) {
                val w = wait
                if (w == null) wake.receive() else withTimeoutOrNull(w.coerceIn(5L, 200L)) { wake.receive() }
                continue
            }
            process(batch)
        }
    }

    private fun isLatest(t: Target) = synchronized(lock) { latest[t.trackId] == t.version }

    private fun emit(t: Target, text: String, translated: String?, src: String?, engine: String?,
                     err: ErrorKind?, same: Boolean = false) {
        if (!isLatest(t)) return
        results.trySend(TranslationResult(t.trackId, t.version, text, translated, src, engine, err, same))
    }

    private suspend fun process(batch: List<Pending>) {
        val p = pair()
        val live = synchronized(lock) {
            batch.map { it to it.targets.filter { t -> latest[t.trackId] == t.version } }
                .filter { it.second.isNotEmpty() }
        }
        if (live.isEmpty()) return

        val srcOf = HashMap<String, String>()
        for ((pd, _) in live) {
            srcOf[pd.key] = if (p.source != Languages.AUTO) p.source else {
                val d = detect(pd.text)?.takeIf { Languages.byCode.containsKey(it) }
                if (d != null) lastDetected = d
                d ?: lastDetected ?: "en"
            }
        }
        for ((src, items) in live.groupBy { srcOf[it.first.key]!! }) {
            if (src == p.target) {
                items.forEach { (pd, ts) -> ts.forEach { emit(it, pd.text, null, src, null, null, same = true) } }
                continue
            }
            val texts = items.map { it.first.text }
            var outs: List<String>? = null
            var engine: String? = null
            var err: TranslationException? = null
            for (prov in providers()) {
                if ((cooldown[prov.id] ?: 0L) > now()) {
                    if (err == null) err = TranslationException(ErrorKind.NETWORK, "${prov.displayName} is cooling down")
                    continue
                }
                try {
                    outs = prov.translate(texts, src, p.target)
                    engine = prov.displayName
                    break
                } catch (e: CancellationException) {
                    throw e
                } catch (e: TranslationException) {
                    err = e
                    if (e.kind == ErrorKind.RATE_LIMIT) cooldown[prov.id] = now() + (if (e.retryAfterMs > 0) e.retryAfterMs else 10_000L)
                    if (e.kind == ErrorKind.NETWORK) cooldown[prov.id] = now() + 3_000L
                } catch (e: Exception) {
                    err = TranslationException(ErrorKind.UNKNOWN, e.message ?: "Translation error")
                }
            }
            val o = outs
            if (o != null && o.size == texts.size) {
                status.value = EngineStatus("$engine · $src→${p.target}", true)
                items.forEachIndexed { i, (pd, ts) ->
                    cache.put(p.source, p.target, pd.text, o[i], engine ?: "")
                    ts.forEach { emit(it, pd.text, o[i], src, engine, null) }
                }
            } else {
                val kind = err?.kind ?: ErrorKind.UNKNOWN
                status.value = EngineStatus(describe(err, src, p.target), false)
                items.forEach { (pd, ts) -> ts.forEach { emit(it, pd.text, null, src, null, kind) } }
            }
        }
    }

    private fun describe(e: TranslationException?, src: String, tgt: String): String = when (e?.kind) {
        ErrorKind.NETWORK -> "No connection to the translation service. Retrying."
        ErrorKind.RATE_LIMIT -> "Rate limited. Online requests paused briefly."
        ErrorKind.MODEL_MISSING -> "Offline pack needed for $src→$tgt. Download it in Settings."
        ErrorKind.NOT_CONFIGURED -> e?.message ?: "Translation engine not configured."
        ErrorKind.UNSUPPORTED -> "This language pair isn't supported by the selected engine."
        else -> "Translation error. Retrying."
    }
}
