package com.livescreentranslator

import android.app.Application
import androidx.room.Room
import com.livescreentranslator.data.AppSettings
import com.livescreentranslator.data.EngineChoice
import com.livescreentranslator.data.RoomTranslationStore
import com.livescreentranslator.data.SecretStore
import com.livescreentranslator.data.SettingsRepository
import com.livescreentranslator.data.TranslationDb
import com.livescreentranslator.translate.GoogleCloudProvider
import com.livescreentranslator.translate.LanguageDetector
import com.livescreentranslator.translate.LibreTranslateProvider
import com.livescreentranslator.translate.MlKitOfflineProvider
import com.livescreentranslator.translate.PackManager
import com.livescreentranslator.translate.TranslationProvider
import com.livescreentranslator.translate.TranslationStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class LstApp : Application() {
    lateinit var graph: AppGraph
        private set

    override fun onCreate() {
        super.onCreate()
        graph = AppGraph(this)
    }
}

/** Tiny hand-rolled service locator. */
class AppGraph(app: Application) {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val settings = SettingsRepository(app)
    /** Null until DataStore has loaded, so the UI never flashes default values. */
    val settingsState: StateFlow<AppSettings?> =
        settings.flow.map<AppSettings, AppSettings?> { it }.stateIn(appScope, SharingStarted.Eagerly, null)
    val secrets = SecretStore(app)
    val db: TranslationDb by lazy { Room.databaseBuilder(app, TranslationDb::class.java, "translations.db").build() }
    val packs = PackManager()
    val detector = LanguageDetector()

    private val offline = MlKitOfflineProvider(packs)
    private val google = GoogleCloudProvider({ settingsNow() }, secrets)
    private val libre = LibreTranslateProvider({ settingsNow() }, secrets)

    fun settingsNow(): AppSettings = settingsState.value ?: AppSettings()

    /**
     * Provider order for the chosen engine. "Offline only" never contacts the network. An explicitly chosen
     * online engine falls back to on-device translation when it fails.
     */
    fun providersFor(s: AppSettings): List<TranslationProvider> = when (s.engine) {
        EngineChoice.OFFLINE -> listOf(offline)
        EngineChoice.GOOGLE -> listOf(google, offline)
        EngineChoice.LIBRE -> listOf(libre, offline)
        EngineChoice.AUTO -> if (s.onlineConsent) listOf(offline, google, libre) else listOf(offline)
    }

    fun newStore(): TranslationStore = RoomTranslationStore(db.dao()) { settingsNow().keepHistory }
}
