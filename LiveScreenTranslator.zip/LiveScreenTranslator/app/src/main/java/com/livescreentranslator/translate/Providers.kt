package com.livescreentranslator.translate

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.livescreentranslator.data.AppSettings
import com.livescreentranslator.data.SecretStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

enum class ErrorKind { NETWORK, RATE_LIMIT, UNSUPPORTED, NOT_CONFIGURED, MODEL_MISSING, UNKNOWN }

class TranslationException(val kind: ErrorKind, message: String, val retryAfterMs: Long = 0) : Exception(message)

interface TranslationProvider {
    val id: String
    val displayName: String
    /** True when extracted text leaves the device. Always disclosed to the user before use. */
    val sendsTextOffDevice: Boolean
    suspend fun translate(texts: List<String>, src: String, tgt: String): List<String>
}

// ---------------------------------------------------------------- language id

class LanguageDetector {
    private val client by lazy {
        LanguageIdentification.getClient(
            LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.45f).build(),
        )
    }

    suspend fun detect(text: String): String? = try {
        normalize(client.identifyLanguage(text.take(200)).await())
    } catch (e: Exception) {
        null
    }

    companion object {
        fun normalize(tag: String): String? {
            if (tag == "und") return null
            return when (val p = tag.substringBefore('-').lowercase()) {
                "iw" -> "he"
                "in" -> "id"
                else -> p
            }
        }
    }
}

// ---------------------------------------------------------------- offline packs

class PackManager {
    private val mgr = RemoteModelManager.getInstance()
    private val _downloaded = MutableStateFlow<Set<String>>(emptySet())
    val downloaded: StateFlow<Set<String>> = _downloaded.asStateFlow()
    private val _busy = MutableStateFlow<Set<String>>(emptySet())
    val busy: StateFlow<Set<String>> = _busy.asStateFlow()

    suspend fun refresh() {
        runCatching {
            val models = mgr.getDownloadedModels(TranslateRemoteModel::class.java).await()
            _downloaded.value = models.map { it.language }.toSet()
        }
    }

    suspend fun download(lang: String, wifiOnly: Boolean): Result<Unit> {
        _busy.update { it + lang }
        return try {
            val cond = DownloadConditions.Builder().apply { if (wifiOnly) requireWifi() }.build()
            mgr.download(TranslateRemoteModel.Builder(lang).build(), cond).await()
            refresh()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            _busy.update { it - lang }
        }
    }

    suspend fun delete(lang: String) {
        runCatching { mgr.deleteDownloadedModel(TranslateRemoteModel.Builder(lang).build()).await() }
        refresh()
    }
}

// ---------------------------------------------------------------- offline provider

class MlKitOfflineProvider(private val packs: PackManager) : TranslationProvider {
    override val id = "offline"
    override val displayName = "On-device"
    override val sendsTextOffDevice = false

    private val translators = object : LinkedHashMap<String, Translator>(4, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Translator>?): Boolean {
            if (size > 3) { eldest?.value?.close(); return true }
            return false
        }
    }
    private var lastRefresh = 0L

    override suspend fun translate(texts: List<String>, src: String, tgt: String): List<String> {
        val s = TranslateLanguage.fromLanguageTag(src)
        val t = TranslateLanguage.fromLanguageTag(tgt)
        if (s == null || t == null) throw TranslationException(ErrorKind.UNSUPPORTED, "Unsupported pair $src→$tgt")
        val now = System.currentTimeMillis()
        if (now - lastRefresh > 10_000) { lastRefresh = now; packs.refresh() }
        val have = packs.downloaded.value
        val missing = listOf(s, t).filter { it != TranslateLanguage.ENGLISH && it !in have }
        if (missing.isNotEmpty()) {
            throw TranslationException(ErrorKind.MODEL_MISSING, "Offline pack missing: ${missing.joinToString()}")
        }
        val tr = synchronized(translators) {
            translators.getOrPut("$s>$t") {
                Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(s).setTargetLanguage(t).build())
            }
        }
        return try {
            texts.map { tr.translate(it).await() }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            throw TranslationException(ErrorKind.MODEL_MISSING, e.message ?: "On-device translation failed")
        }
    }
}

// ---------------------------------------------------------------- online providers

internal object Http {
    fun postJson(url: String, body: String, headers: Map<String, String>): String {
        if (!url.startsWith("https://")) {
            throw TranslationException(ErrorKind.NOT_CONFIGURED, "Endpoint must use https://")
        }
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 4000
            conn.readTimeout = 6000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code in 200..299) return conn.inputStream.bufferedReader().use { it.readText() }
            val retry = (conn.getHeaderField("Retry-After")?.toLongOrNull() ?: 0L) * 1000
            throw when (code) {
                429 -> TranslationException(ErrorKind.RATE_LIMIT, "Rate limited", retry)
                401, 403 -> TranslationException(ErrorKind.NOT_CONFIGURED, "Provider rejected the credentials")
                400 -> TranslationException(ErrorKind.UNSUPPORTED, "Provider rejected the request")
                in 500..599 -> TranslationException(ErrorKind.NETWORK, "Provider error $code")
                else -> TranslationException(ErrorKind.UNKNOWN, "HTTP $code")
            }
        } catch (e: IOException) {
            throw TranslationException(ErrorKind.NETWORK, e.message ?: "Network error")
        } finally {
            conn.disconnect()
        }
    }
}

private fun requireConsent(s: AppSettings) {
    if (!s.onlineConsent) {
        throw TranslationException(ErrorKind.NOT_CONFIGURED, "Online translation is off. Allow it in Settings → Online providers.")
    }
}

/** Google Cloud Translation v2. The key is supplied by the user at runtime, or lives on your own proxy endpoint. */
class GoogleCloudProvider(private val settings: () -> AppSettings, private val secrets: SecretStore) : TranslationProvider {
    override val id = "google"
    override val displayName = "Google Cloud"
    override val sendsTextOffDevice = true

    override suspend fun translate(texts: List<String>, src: String, tgt: String): List<String> = withContext(Dispatchers.IO) {
        val s = settings()
        requireConsent(s)
        val custom = s.googleEndpoint.trim()
        val key = secrets.get(id)
        if (custom.isEmpty() && key == null) {
            throw TranslationException(ErrorKind.NOT_CONFIGURED, "Add a Google Cloud API key or your proxy URL.")
        }
        val url = custom.ifEmpty { "https://translation.googleapis.com/language/translate/v2" }
        val body = JSONObject()
            .put("q", JSONArray(texts)).put("source", src).put("target", tgt).put("format", "text").toString()
        val headers = if (key != null) mapOf("X-Goog-Api-Key" to key) else emptyMap()
        val json = JSONObject(Http.postJson(url, body, headers))
        val arr = json.getJSONObject("data").getJSONArray("translations")
        List(arr.length()) { arr.getJSONObject(it).getString("translatedText") }
    }
}

/** LibreTranslate-compatible server (self-hosted, or any instance the user trusts). */
class LibreTranslateProvider(private val settings: () -> AppSettings, private val secrets: SecretStore) : TranslationProvider {
    override val id = "libre"
    override val displayName = "LibreTranslate"
    override val sendsTextOffDevice = true

    override suspend fun translate(texts: List<String>, src: String, tgt: String): List<String> = withContext(Dispatchers.IO) {
        val s = settings()
        requireConsent(s)
        val base = s.libreEndpoint.trim().trimEnd('/')
        if (base.isEmpty()) throw TranslationException(ErrorKind.NOT_CONFIGURED, "Add your LibreTranslate server URL.")
        val body = JSONObject().put("q", JSONArray(texts)).put("source", src).put("target", tgt).put("format", "text")
        secrets.get(id)?.let { body.put("api_key", it) }
        val json = JSONObject(Http.postJson("$base/translate", body.toString(), emptyMap()))
        val out = json.get("translatedText")
        if (out is JSONArray) List(out.length()) { out.getString(it) } else listOf(out.toString())
    }
}
