package com.livescreentranslator.service

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Process

/** Optional: tells which app is in front so the user can exclude apps. Needs the Usage Access special permission. */
class ForegroundAppDetector(private val ctx: Context) {
    private val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    private var last: String? = null
    private var lastQuery = 0L

    fun current(): String? {
        val now = System.currentTimeMillis()
        val from = if (lastQuery == 0L) now - 10 * 60_000L else lastQuery - 1000L
        lastQuery = now
        runCatching {
            val events = usm.queryEvents(from, now)
            val e = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                if (e.eventType == RESUMED) last = e.packageName
            }
        }
        return last
    }

    companion object {
        // UsageEvents.Event.ACTIVITY_RESUMED (API 29) and MOVE_TO_FOREGROUND (older) are both 1.
        private const val RESUMED = 1

        fun hasUsageAccess(ctx: Context): Boolean {
            val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            } else {
                @Suppress("DEPRECATION")
                ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            }
            return mode == AppOpsManager.MODE_ALLOWED
        }
    }
}
