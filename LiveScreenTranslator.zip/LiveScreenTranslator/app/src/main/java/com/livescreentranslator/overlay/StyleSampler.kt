package com.livescreentranslator.overlay

import android.graphics.Bitmap
import com.livescreentranslator.core.FRect
import com.livescreentranslator.core.LabelStyle
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/** Estimates background colour, text colour and weight of source text from a few hundred sampled pixels. */
object StyleSampler {
    private fun r(c: Int) = (c shr 16) and 0xFF
    private fun g(c: Int) = (c shr 8) and 0xFF
    private fun b(c: Int) = c and 0xFF
    private fun rgb(r: Int, g: Int, b: Int) = (0xFF shl 24) or (r shl 16) or (g shl 8) or b

    fun luminance(c: Int): Float = (0.2126f * r(c) + 0.7152f * g(c) + 0.0722f * b(c)) / 255f
    private fun dist(a: Int, c: Int) = abs(r(a) - r(c)) + abs(g(a) - g(c)) + abs(b(a) - b(c))

    private fun median(values: IntArray): Int {
        val s = values.sortedArray()
        return s[s.size / 2]
    }

    /**
     * @param ring pixels just outside the text box (almost always background)
     * @param inner pixels inside the text box (background plus glyph pixels)
     */
    fun analyze(ring: IntArray, inner: IntArray): LabelStyle {
        if (ring.isEmpty() || inner.isEmpty()) return LabelStyle.DEFAULT
        val bg = rgb(
            median(IntArray(ring.size) { r(ring[it]) }),
            median(IntArray(ring.size) { g(ring[it]) }),
            median(IntArray(ring.size) { b(ring[it]) }),
        )
        var maxD = 0
        var ink = 0
        for (px in inner) {
            val d = dist(px, bg)
            if (d > maxD) maxD = d
            if (d > 150) ink++
        }
        var fg: Int
        if (maxD < 90) {
            fg = if (luminance(bg) > 0.5f) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
        } else {
            var sr = 0L; var sg = 0L; var sb = 0L; var n = 0
            for (px in inner) if (dist(px, bg) >= maxD * 0.6f) { sr += r(px); sg += g(px); sb += b(px); n++ }
            fg = rgb((sr / n).toInt(), (sg / n).toInt(), (sb / n).toInt())
        }
        // Keep the text readable on the sampled background.
        if (abs(luminance(fg) - luminance(bg)) < 0.35f) {
            fg = if (luminance(bg) > 0.5f) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
        }
        val bold = ink.toFloat() / inner.size > 0.27f
        return LabelStyle(bg, fg, bold)
    }

    fun sample(bmp: Bitmap, rect: FRect): LabelStyle {
        val w = bmp.width
        val h = bmp.height
        val l = rect.left.toInt().coerceIn(0, w - 1)
        val t = rect.top.toInt().coerceIn(0, h - 1)
        val rr = rect.right.toInt().coerceIn(l + 1, w)
        val bb = rect.bottom.toInt().coerceIn(t + 1, h)
        val bw = rr - l
        val bh = bb - t
        if (bw < 3 || bh < 3) return LabelStyle.DEFAULT

        val ring = ArrayList<Int>()
        val ol = (l - 3).coerceAtLeast(0); val orr = (rr + 2).coerceAtMost(w - 1)
        val ot = (t - 3).coerceAtLeast(0); val ob = (bb + 2).coerceAtMost(h - 1)
        val stepX = max(1, bw / 24)
        var x = ol
        while (x <= orr) { ring += bmp.getPixel(x, ot); ring += bmp.getPixel(x, ob); x += stepX }
        val stepY = max(1, bh / 12)
        var y = ot
        while (y <= ob) { ring += bmp.getPixel(ol, y); ring += bmp.getPixel(orr, y); y += stepY }

        val step = max(1, sqrt(bw.toFloat() * bh / 600f).toInt())
        val inner = ArrayList<Int>()
        var yy = t
        while (yy < bb) {
            var xx = l
            while (xx < rr) { inner += bmp.getPixel(xx, yy); xx += step }
            yy += step
        }
        return analyze(ring.toIntArray(), inner.toIntArray())
    }
}

/** Pure helpers for the typewriter reveal, kept free of Android types so they can be unit-tested. */
object RevealMath {
    /** Grapheme-cluster boundaries as char offsets: first is 0, last is text.length. */
    fun breaks(text: String): IntArray {
        if (text.isEmpty()) return intArrayOf(0)
        val it = java.text.BreakIterator.getCharacterInstance()
        it.setText(text)
        val out = ArrayList<Int>()
        out += 0
        var b = it.next()
        while (b != java.text.BreakIterator.DONE) { out += b; b = it.next() }
        return out.toIntArray()
    }

    /** Number of whole graphemes of [new] that are identical to the start of [old]. */
    fun commonPrefixGraphemes(old: String, new: String): Int {
        var n = 0
        val max = minOf(old.length, new.length)
        while (n < max && old[n] == new[n]) n++
        val br = breaks(new)
        var count = 0
        for (i in 1 until br.size) if (br[i] <= n) count = i
        return count
    }

    /** Characters per second for the reveal: quick for long text so a paragraph never takes more than ~1 s. */
    fun charsPerSecond(graphemes: Int, speed: Float): Float =
        (graphemes / 1.0f).coerceIn(45f, 220f) * speed
}
