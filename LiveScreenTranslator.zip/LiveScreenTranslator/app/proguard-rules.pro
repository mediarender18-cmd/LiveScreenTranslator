# ML Kit and Room ship their own consumer rules. Nothing extra needed.
-keep class com.livescreentranslator.overlay.OverlayHostService { *; }
